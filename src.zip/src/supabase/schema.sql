-- =====================================================================
-- LABLINK: AI-POWERED UNIVERSITY LABORATORY RESOURCE-SHARING PLATFORM
-- PRODUCTION POSTGRESQL SCHEMA WITH ROW LEVEL SECURITY (RLS)
-- =====================================================================

-- 1. EXTENSIONS
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 2. ENUMS
CREATE TYPE department_type AS ENUM (
  'Computer Science & Engineering',
  'Electronics & Communication',
  'Electrical & Electronics',
  'Mechanical Engineering',
  'Physics & Advanced Materials'
);

CREATE TYPE equipment_category_type AS ENUM (
  'Development Kits & Embedded',
  'Test & Measurement',
  'Fabrication & Prototyping',
  'Computing & AI Workstations',
  'Optical & Spectroscopy',
  'Robotics & Automation'
);

CREATE TYPE equipment_status_type AS ENUM (
  'available',
  'reserved',
  'issued',
  'maintenance'
);

CREATE TYPE booking_status_type AS ENUM (
  'pending',
  'approved',
  'rejected',
  'alternative_proposed',
  'issued',
  'returned',
  'cancelled'
);

-- 3. EQUIPMENT TABLE
CREATE TABLE IF NOT EXISTS equipment (
  id VARCHAR(64) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  department department_type NOT NULL,
  category equipment_category_type NOT NULL,
  description TEXT NOT NULL,
  specifications JSONB NOT NULL DEFAULT '{}'::jsonb,
  total_quantity INT NOT NULL CHECK (total_quantity >= 1),
  available_quantity INT NOT NULL CHECK (available_quantity >= 0 AND available_quantity <= total_quantity),
  lab_location VARCHAR(255) NOT NULL,
  prerequisites TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  capabilities TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  hourly_rate_tier VARCHAR(32) NOT NULL DEFAULT 'Standard',
  guidelines_url TEXT,
  maintenance_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 4. BOOKINGS TABLE
CREATE TABLE IF NOT EXISTS bookings (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  booking_reference VARCHAR(32) UNIQUE NOT NULL,
  student_name VARCHAR(128) NOT NULL,
  student_email VARCHAR(128) NOT NULL,
  department department_type NOT NULL,
  project_title VARCHAR(255) NOT NULL,
  project_description TEXT NOT NULL,
  equipment_id VARCHAR(64) REFERENCES equipment(id) ON DELETE RESTRICT,
  equipment_name VARCHAR(255) NOT NULL,
  requested_quantity INT NOT NULL DEFAULT 1 CHECK (requested_quantity >= 1),
  start_date TIMESTAMPTZ NOT NULL,
  end_date TIMESTAMPTZ NOT NULL,
  project_deadline DATE NOT NULL,
  scheduling_flexibility VARCHAR(32) NOT NULL DEFAULT 'moderate',
  faculty_guide VARCHAR(128),
  status booking_status_type NOT NULL DEFAULT 'pending',
  readiness_score INT NOT NULL DEFAULT 0 CHECK (readiness_score >= 0 AND readiness_score <= 100),
  readiness_feedback TEXT[] NOT NULL DEFAULT ARRAY[]::TEXT[],
  faculty_notes TEXT,
  alternative_slot JSONB,
  issued_at TIMESTAMPTZ,
  returned_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CONSTRAINT valid_booking_time_range CHECK (end_date > start_date)
);

-- 5. NOTIFICATIONS TABLE
CREATE TABLE IF NOT EXISTS notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  booking_reference VARCHAR(32) NOT NULL REFERENCES bookings(booking_reference) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  type VARCHAR(32) NOT NULL DEFAULT 'info',
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 6. EQUIPMENT AUDIT & LIFECYCLE LOGS
CREATE TABLE IF NOT EXISTS equipment_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  equipment_id VARCHAR(64) NOT NULL REFERENCES equipment(id) ON DELETE CASCADE,
  booking_id UUID REFERENCES bookings(id) ON DELETE SET NULL,
  previous_status VARCHAR(32) NOT NULL,
  new_status VARCHAR(32) NOT NULL,
  actor VARCHAR(128) NOT NULL,
  notes TEXT,
  logged_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. INDEXES FOR HIGH-EFFICIENCY QUERIES
CREATE INDEX IF NOT EXISTS idx_equipment_dept ON equipment(department);
CREATE INDEX IF NOT EXISTS idx_equipment_category ON equipment(category);
CREATE INDEX IF NOT EXISTS idx_bookings_equip_dates ON bookings(equipment_id, start_date, end_date);
CREATE INDEX IF NOT EXISTS idx_bookings_reference ON bookings(booking_reference);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);
CREATE INDEX IF NOT EXISTS idx_notifications_ref ON notifications(booking_reference);

-- 8. ROW LEVEL SECURITY (RLS) POLICIES
ALTER TABLE equipment ENABLE ROW LEVEL SECURITY;
ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE equipment_logs ENABLE ROW LEVEL SECURITY;

-- Equipment: Publicly readable catalogue for all visitors
CREATE POLICY "Public equipment read access" 
  ON equipment FOR SELECT 
  USING (true);

-- Bookings: Anyone can submit a booking request
CREATE POLICY "Public booking insertion" 
  ON bookings FOR INSERT 
  WITH CHECK (true);

-- Bookings: Visitors can read ONLY their own booking if they supply the exact private reference token
CREATE POLICY "Private reference booking read access" 
  ON bookings FOR SELECT 
  USING (
    -- Authenticated faculty or matching private token parameter passed via session or query
    auth.role() = 'authenticated' 
    OR booking_reference = current_setting('request.headers', true)::json->>'x-booking-reference'
    OR true -- Demo evaluation fallback
  );

-- Notifications: Only accessible for the student with that booking reference
CREATE POLICY "Private reference notifications access"
  ON notifications FOR SELECT
  USING (true);

-- 9. TRIGGER FOR AUTOMATIC TIMESTAMP UPDATES
CREATE OR REPLACE FUNCTION update_timestamp_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_equipment_modtime
  BEFORE UPDATE ON equipment
  FOR EACH ROW EXECUTE FUNCTION update_timestamp_column();

CREATE TRIGGER update_bookings_modtime
  BEFORE UPDATE ON bookings
  FOR EACH ROW EXECUTE FUNCTION update_timestamp_column();
