import { Equipment } from '../types';

export const INITIAL_EQUIPMENT: Equipment[] = [
  // Computer Science & Engineering
  {
    id: 'eq-cs-01',
    name: 'NVIDIA DGX A100 AI Workstation',
    department: 'Computer Science & Engineering',
    category: 'Computing & AI Workstations',
    description: 'High-throughput enterprise AI computing node equipped with 4x NVIDIA A100 Tensor Core GPUs, optimized for training large language models, computer vision neural networks, and high-performance scientific simulations.',
    specifications: {
      'GPU': '4x NVIDIA A100 80GB SXM4',
      'CPU': 'Dual AMD EPYC 7742 (128 Cores total)',
      'System RAM': '1 TB DDR4 ECC',
      'Storage': '15 TB NVMe High-Speed SSD Array',
      'Environment': 'Ubuntu 22.04 LTS, CUDA 12.2, PyTorch, TensorFlow, vLLM'
    },
    totalQuantity: 2,
    availableQuantity: 1,
    labLocation: 'CS Block, 3rd Floor, Lab 304 (AI & High-Performance Computing Center)',
    prerequisites: ['Basic Linux Shell Competency', 'HPC Cluster Safety & Resource Ethics'],
    capabilities: [
      'deep learning', 'neural networks', 'llm', 'large language model',
      'pytorch', 'tensorflow', 'cuda', 'computer vision', 'gpu computing',
      'ai model training', 'natural language processing', 'transformer'
    ],
    hourlyRateTier: 'Specialized',
    guidelinesUrl: 'https://lablink.university.edu/docs/ai-cluster-policy'
  },
  {
    id: 'eq-cs-02',
    name: 'Intel RealSense D435i Depth Camera Kit',
    department: 'Computer Science & Engineering',
    category: 'Robotics & Automation',
    description: 'High-precision stereo depth camera with integrated Bosch inertial measurement unit (IMU) for 6-DOF tracking, real-time spatial mapping, and autonomous robot navigation.',
    specifications: {
      'Depth Technology': 'Active IR Stereo',
      'Depth FOV': '87° × 58°',
      'Depth Output Resolution': 'Up to 1280 × 720 at 90 fps',
      'IMU': 'BMI055 6-DoF (Accelerometer + Gyroscope)',
      'Interface': 'USB-C 3.1 Gen 1'
    },
    totalQuantity: 5,
    availableQuantity: 4,
    labLocation: 'CS Block, 2nd Floor, Lab 208 (Robotics & Perception Lab)',
    prerequisites: ['Computer Vision Fundamentals'],
    capabilities: [
      'computer vision', 'depth sensing', 'slam', 'spatial mapping',
      'robotics', 'autonomous navigation', '3d scanning', 'point cloud',
      'object detection', 'ros', 'robot operating system'
    ],
    hourlyRateTier: 'Standard',
  },
  {
    id: 'eq-cs-03',
    name: 'Google Coral Dev Board (Edge TPU)',
    department: 'Computer Science & Engineering',
    category: 'Development Kits & Embedded',
    description: 'Single-board computer with on-board Edge TPU coprocessor capable of performing 4 trillion operations per second (TOPS), engineered for on-device machine learning inference at ultra-low power.',
    specifications: {
      'Edge TPU': 'Coproc 4 TOPS (int8) @ 2W',
      'CPU': 'NXP i.MX 8M SoC (Quad Cortex-A53 + Cortex-M4F)',
      'RAM': '4 GB LPDDR4',
      'Flash Memory': '8 GB eMMC',
      'Connectivity': 'Wi-Fi 802.11ac, Bluetooth 4.2, Gigabit Ethernet'
    },
    totalQuantity: 6,
    availableQuantity: 5,
    labLocation: 'CS Block, 1st Floor, Lab 102 (IoT & Edge Computing Studio)',
    prerequisites: ['Embedded Systems Basics'],
    capabilities: [
      'edge ai', 'tinyml', 'embedded', 'iot', 'tensorflow lite',
      'sensor integration', 'low power inference', 'microcontroller',
      'smart camera', 'smart agriculture'
    ],
    hourlyRateTier: 'Standard',
  },

  // Electronics & Communication
  {
    id: 'eq-ece-01',
    name: 'Keysight DSOX3024T Digital Storage Oscilloscope',
    department: 'Electronics & Communication',
    category: 'Test & Measurement',
    description: '4-channel 200 MHz digital storage oscilloscope with 1,000,000 waveforms/sec update rate, capacitive touchscreen, and integrated protocol hardware decoder (I2C, SPI, UART, CAN).',
    specifications: {
      'Bandwidth': '200 MHz',
      'Channels': '4 Analog Channels',
      'Sample Rate': 'Up to 5 GSa/s',
      'Memory Depth': '4 Mpts',
      'Bus Decoding': 'I2C, SPI, UART/RS232, CAN, LIN'
    },
    totalQuantity: 4,
    availableQuantity: 2,
    labLocation: 'ECE Block, 2nd Floor, Lab 215 (Signal Processing & Embedded Lab)',
    prerequisites: ['Basic Circuit Theory', 'ESD (Electrostatic Discharge) Protection Protocol'],
    capabilities: [
      'oscilloscope', 'signal analysis', 'waveform debugging', 'i2c', 'spi',
      'uart', 'embedded debugging', 'analog circuits', 'transceiver testing',
      'frequency response', 'jitter analysis'
    ],
    hourlyRateTier: 'Standard',
  },
  {
    id: 'eq-ece-02',
    name: 'Xilinx Zynq-7000 SoC FPGA Development Kit (ZedBoard)',
    department: 'Electronics & Communication',
    category: 'Development Kits & Embedded',
    description: 'Heterogeneous evaluation board coupling a dual-core ARM Cortex-A9 processor with traditional Xilinx 7-series programmable logic, ideal for hardware-accelerated algorithms and reconfigurable computing.',
    specifications: {
      'Device': 'XC7Z020-CLG484-1 AP SoC',
      'Processor': 'Dual ARM Cortex-A9 @ 667 MHz',
      'Logic Cells': '85,000 Programmable Logic Cells',
      'Memory': '512 MB DDR3, 256 MB Quad-SPI Flash',
      'Interfaces': 'HDMI Output, VGA, Gigabit Ethernet, USB OTG, FMC Connector'
    },
    totalQuantity: 4,
    availableQuantity: 3,
    labLocation: 'ECE Block, 3rd Floor, Lab 320 (VLSI & FPGA Design Laboratory)',
    prerequisites: ['Digital Design Fundamentals', 'Verilog/VHDL Proficiency'],
    capabilities: [
      'fpga', 'verilog', 'vhdl', 'hardware acceleration', 'zynq',
      'digital signal processing', 'embedded linux', 'custom coprocessor',
      'vlsi design', 'reconfigurable logic'
    ],
    hourlyRateTier: 'Specialized',
  },
  {
    id: 'eq-ece-03',
    name: 'Anritsu MS2830A RF Spectrum Analyzer (9 kHz - 6 GHz)',
    department: 'Electronics & Communication',
    category: 'Test & Measurement',
    description: 'Precision microwave and RF spectrum analyzer with high dynamic range, built-in vector signal analysis for 5G, Wi-Fi 6, LoRa, and satellite communication prototyping.',
    specifications: {
      'Frequency Range': '9 kHz to 6 GHz',
      'DANL': '-153 dBm/Hz @ 1 GHz',
      'Analysis Bandwidth': '31.25 MHz standard (up to 125 MHz optional)',
      'Phase Noise': '-122 dBc/Hz @ 1 GHz (10 kHz offset)',
      'Demodulation': 'LTE, W-CDMA, GSM, WLAN 802.11a/b/g/n/ac'
    },
    totalQuantity: 2,
    availableQuantity: 1,
    labLocation: 'ECE Block, 4th Floor, Lab 402 (Advanced Microwave & Antenna Research Wing)',
    prerequisites: ['RF Engineering Theory', 'High-Frequency Instrument Handling'],
    capabilities: [
      'rf testing', 'spectrum analysis', 'wireless communication', 'antenna',
      'lora', '5g', 'wifi', 'harmonics measurement', 'emi testing',
      'signal interference'
    ],
    hourlyRateTier: 'Specialized',
  },

  // Electrical & Electronics
  {
    id: 'eq-ee-01',
    name: 'Chroma 6310A Programmable DC Electronic Load',
    department: 'Electrical & Electronics',
    category: 'Test & Measurement',
    description: 'Modular high-precision DC electronic load for testing multi-output AC/DC power supplies, DC/DC converters, EV battery degradation, and solar photovoltaic charge controllers.',
    specifications: {
      'Power Rating': '600 W per module',
      'Voltage Range': '1 V to 80 V / 500 V',
      'Current Range': 'Up to 120 A',
      'Operating Modes': 'Constant Current (CC), Constant Resistance (CR), Constant Voltage (CV), Constant Power (CP)',
      'Dynamic Frequency': 'Up to 20 kHz'
    },
    totalQuantity: 3,
    availableQuantity: 2,
    labLocation: 'EE Block, 1st Floor, Lab 110 (Power Electronics & Renewable Energy Lab)',
    prerequisites: ['High Voltage Safety Certification', 'DC Power Handling Protocol'],
    capabilities: [
      'power electronics', 'battery testing', 'solar pv', 'inverter evaluation',
      'dc load testing', 'ev charging', 'constant current', 'power efficiency',
      'converter debugging'
    ],
    hourlyRateTier: 'Standard',
  },
  {
    id: 'eq-ee-02',
    name: 'dSPACE MicroLabBox High-Performance Controller',
    department: 'Electrical & Electronics',
    category: 'Robotics & Automation',
    description: 'All-in-one laboratory hardware-in-the-loop (HIL) rapid control prototyping system directly programmable from MATLAB Simulink, built for advanced electric drives and mechatronics control.',
    specifications: {
      'Processor': 'Dual-core NXP QorIQ P5020 @ 2 GHz',
      'Analog Inputs': '8 channels 16-bit 10 Msps + 24 channels 16-bit 1 Msps',
      'Analog Outputs': '16 channels 16-bit 1 Msps',
      'Digital I/O': '48 channels bi-directional',
      'Host Interface': 'Gigabit Ethernet, MATLAB / Simulink 2024b Blockset'
    },
    totalQuantity: 2,
    availableQuantity: 1,
    labLocation: 'EE Block, 2nd Floor, Lab 205 (Control Systems & Electric Drives Lab)',
    prerequisites: ['MATLAB/Simulink Certification', 'Electric Machine Safety'],
    capabilities: [
      'hardware in the loop', 'hil', 'matlab', 'simulink', 'motor control',
      'electric drive', 'control systems', 'rapid prototyping', 'pmsm', 'bldc'
    ],
    hourlyRateTier: 'Specialized',
  },

  // Mechanical Engineering
  {
    id: 'eq-mech-01',
    name: 'Ultimaker S5 Dual-Extrusion 3D Printer',
    department: 'Mechanical Engineering',
    category: 'Fabrication & Prototyping',
    description: 'Industrial-grade dual-extrusion desktop 3D printer with large build volume, active bed levelling, and composite material capability (PLA, Tough PLA, ABS, Nylon, PVA water-soluble supports).',
    specifications: {
      'Build Volume': '330 × 240 × 300 mm',
      'Layer Resolution': 'Down to 20 microns (0.02 mm)',
      'Nozzle Temperature': 'Up to 280 °C',
      'Build Plate': 'Heated glass / aluminum up to 140 °C',
      'Materials Supported': 'PLA, ABS, Nylon, CPE, TPU 95A, PC, PP, Water-soluble PVA'
    },
    totalQuantity: 4,
    availableQuantity: 3,
    labLocation: 'Mech Block, Ground Floor, Central Workshop - Rapid Prototyping Lab',
    prerequisites: ['Additive Manufacturing Safety Induction', 'CAD File Preparation (STL/STEP)'],
    capabilities: [
      '3d printing', 'rapid prototyping', 'additive manufacturing', 'cad',
      'mechanical enclosure', 'chassis fabrication', 'structural modeling',
      'dual extrusion', 'pla', 'abs', 'functional prototype'
    ],
    hourlyRateTier: 'Standard',
  },
  {
    id: 'eq-mech-02',
    name: 'Universal Laser Systems VLS3.50 Laser Cutter',
    department: 'Mechanical Engineering',
    category: 'Fabrication & Prototyping',
    description: '50-watt precision CO2 laser cutting and engraving platform for acrylic, Delrin, wood, paper, gasket material, and non-metal sheet components with micro-kerf accuracy.',
    specifications: {
      'Work Area': '610 × 305 mm',
      'Laser Power': '50 Watts CO2 Cartridge',
      'Max Material Thickness': 'Up to 10 mm (Acrylic/Wood)',
      'Fume Extraction': 'Integrated High-Efficiency Air Filter and Blower',
      'Supported Formats': 'DXF, DWG, SVG, PDF Vector Profiles'
    },
    totalQuantity: 2,
    availableQuantity: 1,
    labLocation: 'Mech Block, Ground Floor, Central Fabrication Facility',
    prerequisites: ['Laser Safety Clearance (Class 4 Enclosed)', 'Material Fume Safety Review'],
    capabilities: [
      'laser cutting', 'acrylic cutting', 'enclosure fabrication', 'vector cutting',
      'engraving', 'precision fabrication', 'rapid prototyping', 'chassis',
      'robot body', 'mechanical brackets'
    ],
    hourlyRateTier: 'Specialized',
  },
  {
    id: 'eq-mech-03',
    name: 'Instron 3369 Universal Tensile Testing Machine (50 kN)',
    department: 'Mechanical Engineering',
    category: 'Test & Measurement',
    description: 'Electromechanical universal testing system with 50 kN load capacity for conducting tension, compression, bend, shear, and peel testing of polymers, composites, and structural alloys.',
    specifications: {
      'Load Capacity': '50 kN (11,250 lbf)',
      'Crosshead Speed Range': '0.005 to 500 mm/min',
      'Vertical Test Space': '1193 mm',
      'Load Cell Accuracy': '±0.5% of reading down to 1/250 of load cell capacity',
      'Software': 'Bluehill Universal Materials Testing Suite'
    },
    totalQuantity: 1,
    availableQuantity: 1,
    labLocation: 'Mech Block, Basement, Materials Testing & Metallurgy Lab',
    prerequisites: ['Materials Testing Safety Course', 'Instron Operator Certification'],
    capabilities: [
      'tensile testing', 'stress strain analysis', 'material strength',
      'compression testing', 'yield strength', 'polymer testing',
      'composite materials', 'mechanical characterization'
    ],
    hourlyRateTier: 'Specialized',
  },

  // Physics & Advanced Materials
  {
    id: 'eq-phys-01',
    name: 'Keithley 2450 Interactive SourceMeter SMU Instrument',
    department: 'Physics & Advanced Materials',
    category: 'Test & Measurement',
    description: 'Touchscreen Source Measure Unit (SMU) that simultaneously sources and measures voltage and current with 0.012% basic accuracy and 6½-digit resolution, perfect for nanomaterials and solar cells.',
    specifications: {
      'Voltage Source/Measure': '20 mV to 200 V',
      'Current Source/Measure': '10 nA to 1 A',
      'Power Output': '20 W maximum',
      'Measurement Resolution': '10 fA / 10 nV',
      'Display': '5-inch full-color capacitive touchscreen with graphical I-V curve plotting'
    },
    totalQuantity: 3,
    availableQuantity: 2,
    labLocation: 'Physics Block, 2nd Floor, Lab 202 (Nanomaterials & Semiconductor Lab)',
    prerequisites: ['Cleanroom Level 1 Access', 'Microprobe Station Handling'],
    capabilities: [
      'iv characterization', 'semiconductor testing', 'nanomaterials',
      'thin film resistance', 'photovoltaic testing', 'current voltage curve',
      'low current measurement', 'sensor characterization', 'graphene'
    ],
    hourlyRateTier: 'High-Demand',
  },
  {
    id: 'eq-phys-02',
    name: 'Shimadzu UV-2600 UV-Vis Spectrophotometer',
    department: 'Physics & Advanced Materials',
    category: 'Optical & Spectroscopy',
    description: 'Double-beam UV-Vis spectrophotometer featuring an ultra-low stray light monochromator, spanning 185 nm to 900 nm (expandable to 1400 nm) for optical absorption and bandgap determination.',
    specifications: {
      'Wavelength Range': '185 to 900 nm',
      'Spectral Bandwidth': '0.1 to 5 nm (selectable)',
      'Photometric Range': '-5 to +5 Absorbance units',
      'Wavelength Accuracy': '±0.1 nm',
      'Accessories': 'Integrating Sphere for solid thin-film reflection/transmittance'
    },
    totalQuantity: 2,
    availableQuantity: 1,
    labLocation: 'Physics Block, 3rd Floor, Lab 305 (Optics & Spectroscopy Center)',
    prerequisites: ['Chemical Safety & Cuvette Handling', 'Optical Alignment Protocol'],
    capabilities: [
      'spectroscopy', 'uv vis', 'optical absorption', 'bandgap analysis',
      'photoluminescence', 'chemical concentration', 'nanoparticle characterization',
      'thin film transmittance', 'solar cell absorption'
    ],
    hourlyRateTier: 'High-Demand',
  }
];

export const INITIAL_BOOKINGS = [
  {
    id: 'b-demo-01',
    bookingReference: 'LL-7F2A-91K4',
    studentName: 'Aarav Sharma',
    studentEmail: 'aarav.sharma@uni.edu',
    department: 'Computer Science & Engineering',
    projectTitle: 'Autonomous Greenhouse Monitoring & Irrigation using Edge AI',
    projectDescription: 'Developing an energy-efficient greenhouse climate regulation system with TinyML edge inference and camera vision for plant disease detection.',
    equipmentId: 'eq-cs-03',
    equipmentName: 'Google Coral Dev Board (Edge TPU)',
    requestedQuantity: 1,
    startDate: new Date(Date.now() + 86400000 * 2).toISOString().slice(0, 10) + 'T09:00:00Z',
    endDate: new Date(Date.now() + 86400000 * 2).toISOString().slice(0, 10) + 'T13:00:00Z',
    projectDeadline: new Date(Date.now() + 86400000 * 7).toISOString().slice(0, 10),
    schedulingFlexibility: 'moderate' as const,
    facultyGuide: 'Dr. Ramesh Kumar (Dept of CSE)',
    status: 'approved' as const,
    readinessScore: 92,
    readinessFeedback: ['Project description is well specified', 'Prerequisites checked and verified'],
    facultyNotes: 'Approved for research batch 2026. Please collect kit from Lab 102.',
    createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
    updatedAt: new Date(Date.now() - 86400000 * 1).toISOString(),
  },
  {
    id: 'b-demo-02',
    bookingReference: 'LL-3C8D-44P9',
    studentName: 'Meera Nambiar',
    studentEmail: 'meera.n@uni.edu',
    department: 'Electronics & Communication',
    projectTitle: 'FPGA-based Hardware Accelerator for Convolutional Neural Networks',
    projectDescription: 'Synthesizing pipelined MAC systolic arrays on FPGA to accelerate 8-bit quantized ResNet-18 image classification.',
    equipmentId: 'eq-ece-02',
    equipmentName: 'Xilinx Zynq-7000 SoC FPGA Development Kit (ZedBoard)',
    requestedQuantity: 1,
    startDate: new Date(Date.now() + 86400000 * 3).toISOString().slice(0, 10) + 'T10:00:00Z',
    endDate: new Date(Date.now() + 86400000 * 3).toISOString().slice(0, 10) + 'T16:00:00Z',
    projectDeadline: new Date(Date.now() + 86400000 * 10).toISOString().slice(0, 10),
    schedulingFlexibility: 'flexible' as const,
    facultyGuide: 'Prof. Ananya Sen (Dept of ECE)',
    status: 'issued' as const,
    readinessScore: 96,
    readinessFeedback: ['High-quality proposal with verified Vivado toolflow prerequisite'],
    facultyNotes: 'ZedBoard unit #2 issued. Return expected before Friday 5 PM.',
    issuedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 4).toISOString(),
  },
  // Conflicting booking pair on the sole available A100 GPU workstation to demonstrate the Conflict Engine
  {
    id: 'b-conflict-01',
    bookingReference: 'LL-9X1B-22M8',
    studentName: 'Rohan Deshmukh',
    studentEmail: 'rohan.d@uni.edu',
    department: 'Computer Science & Engineering',
    projectTitle: 'Fine-Tuning Medical Domain LLM for Radiology Triage',
    projectDescription: 'Training 7B parameter medical model on multi-modal chest X-ray findings. Urgent final thesis defense in 4 days.',
    equipmentId: 'eq-cs-01',
    equipmentName: 'NVIDIA DGX A100 AI Workstation',
    requestedQuantity: 1,
    startDate: new Date(Date.now() + 86400000 * 1).toISOString().slice(0, 10) + 'T09:00:00Z',
    endDate: new Date(Date.now() + 86400000 * 1).toISOString().slice(0, 10) + 'T17:00:00Z',
    projectDeadline: new Date(Date.now() + 86400000 * 4).toISOString().slice(0, 10),
    schedulingFlexibility: 'strict' as const,
    facultyGuide: 'Dr. Sundar Rajan (Dept of CSE)',
    status: 'pending' as const,
    readinessScore: 95,
    readinessFeedback: ['Dataset and training scripts already staged', 'Safety ethics verified'],
    createdAt: new Date(Date.now() - 3600000 * 6).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 6).toISOString(),
  },
  {
    id: 'b-conflict-02',
    bookingReference: 'LL-5E7T-88Q3',
    studentName: 'Pooja Hegde',
    studentEmail: 'pooja.hegde@uni.edu',
    department: 'Electronics & Communication',
    projectTitle: 'Cross-Department Deep Learning for Antenna Radiation Pattern Synthesis',
    projectDescription: 'Simulating complex electromagnetic radiation matrices using physics-informed neural networks. Capstone deadline in 18 days.',
    equipmentId: 'eq-cs-01',
    equipmentName: 'NVIDIA DGX A100 AI Workstation',
    requestedQuantity: 1,
    startDate: new Date(Date.now() + 86400000 * 1).toISOString().slice(0, 10) + 'T11:00:00Z',
    endDate: new Date(Date.now() + 86400000 * 1).toISOString().slice(0, 10) + 'T16:00:00Z',
    projectDeadline: new Date(Date.now() + 86400000 * 18).toISOString().slice(0, 10),
    schedulingFlexibility: 'flexible' as const,
    facultyGuide: 'Dr. Vikram Seth (Dept of ECE)',
    status: 'pending' as const,
    readinessScore: 88,
    readinessFeedback: ['Cross-department initiative strongly supported', 'Flexible timing available'],
    createdAt: new Date(Date.now() - 3600000 * 3).toISOString(),
    updatedAt: new Date(Date.now() - 3600000 * 3).toISOString(),
  }
];

export const INITIAL_NOTIFICATIONS = [
  {
    id: 'notif-1',
    bookingReference: 'LL-7F2A-91K4',
    title: 'Booking Approved',
    message: 'Your request for Google Coral Dev Board was approved by Dr. Ramesh Kumar. Collection slot: 09:00 AM in Lab 102.',
    type: 'success' as const,
    createdAt: new Date(Date.now() - 86400000 * 1).toISOString(),
    read: false,
  },
  {
    id: 'notif-2',
    bookingReference: 'LL-3C8D-44P9',
    title: 'Equipment Issued',
    message: 'Xilinx Zynq-7000 SoC FPGA Development Kit (ZedBoard) was checked out to you. Expected return: Friday 17:00.',
    type: 'info' as const,
    createdAt: new Date(Date.now() - 3600000 * 4).toISOString(),
    read: true,
  },
  {
    id: 'notif-3',
    bookingReference: 'LL-9X1B-22M8',
    title: 'Booking Under Review & Conflict Check',
    message: 'Your booking request is queued for NVIDIA DGX A100. Overlap detected with competing project; Fair-Share resolution running.',
    type: 'warning' as const,
    createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
    read: false,
  }
];
