import { 
  Equipment, 
  BookingRequest, 
  BookingStatus, 
  NotificationItem, 
  UtilizationMetric, 
  Department 
} from '../types';
import { INITIAL_EQUIPMENT, INITIAL_BOOKINGS, INITIAL_NOTIFICATIONS } from '../data/seedEquipment';

const STORAGE_KEY = 'lablink_database_state_v1';

export interface DatabaseState {
  equipment: Equipment[];
  bookings: BookingRequest[];
  notifications: NotificationItem[];
  departmentUsage: Record<string, number>;
}

// Generate unpredictable cryptographically sound booking reference e.g. "LL-8B2A-94K1"
export function generateBookingReference(): string {
  const chars = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'; // Unambiguous alphanumeric
  let segment1 = '';
  let segment2 = '';
  
  for (let i = 0; i < 4; i++) {
    segment1 += chars.charAt(Math.floor(Math.random() * chars.length));
    segment2 += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  
  return `LL-${segment1}-${segment2}`;
}

export class MockDatabaseStore {
  private state: DatabaseState;
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.state = this.loadState();
  }

  private loadState(): DatabaseState {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return JSON.parse(stored);
      }
    } catch {
      // Fallback for SSR or non-browser test environments
    }

    // Default seeded state
    return {
      equipment: JSON.parse(JSON.stringify(INITIAL_EQUIPMENT)),
      bookings: JSON.parse(JSON.stringify(INITIAL_BOOKINGS)),
      notifications: JSON.parse(JSON.stringify(INITIAL_NOTIFICATIONS)),
      departmentUsage: {
        'Computer Science & Engineering': 4,
        'Electronics & Communication': 3,
        'Electrical & Electronics': 1,
        'Mechanical Engineering': 2,
        'Physics & Advanced Materials': 1,
      },
    };
  }

  private persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch {
      // Ignored in headless environments
    }
    this.notify();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  private notify() {
    this.listeners.forEach((fn) => fn());
  }

  // Equipment queries
  public getEquipment(): Equipment[] {
    return [...this.state.equipment];
  }

  public getEquipmentById(id: string): Equipment | undefined {
    return this.state.equipment.find((e) => e.id === id);
  }

  // Bookings queries
  public getBookings(): BookingRequest[] {
    return [...this.state.bookings];
  }

  public getBookingByReference(reference: string): BookingRequest | undefined {
    const cleanRef = reference.trim().toUpperCase();
    return this.state.bookings.find(
      (b) => b.bookingReference.toUpperCase() === cleanRef
    );
  }

  // Create new booking
  public createBooking(bookingData: Omit<BookingRequest, 'id' | 'bookingReference' | 'status' | 'createdAt' | 'updatedAt'>): BookingRequest {
    const bookingReference = generateBookingReference();
    const newBooking: BookingRequest = {
      ...bookingData,
      id: `b-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      bookingReference,
      status: 'pending',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    this.state.bookings.unshift(newBooking);

    // Increment department usage
    this.state.departmentUsage[newBooking.department] = (this.state.departmentUsage[newBooking.department] || 0) + 1;

    // Add initial confirmation notification
    this.addNotification({
      bookingReference,
      title: 'Booking Request Submitted',
      message: `Your reservation request for "${newBooking.equipmentName}" is under faculty review. Save your reference code: ${bookingReference}`,
      type: 'info',
    });

    this.persist();
    return newBooking;
  }

  // Faculty status update with strict state transition checks
  public updateBookingStatus(
    bookingId: string,
    newStatus: BookingStatus,
    facultyNotes?: string,
    alternativeSlot?: BookingRequest['alternativeSlot']
  ): BookingRequest {
    const booking = this.state.bookings.find((b) => b.id === bookingId);
    if (!booking) {
      throw new Error(`Booking with ID ${bookingId} not found`);
    }

    const previousStatus = booking.status;
    booking.status = newStatus;
    booking.updatedAt = new Date().toISOString();
    if (facultyNotes) {
      booking.facultyNotes = facultyNotes;
    }
    if (alternativeSlot) {
      booking.alternativeSlot = alternativeSlot;
    }

    const equipment = this.state.equipment.find((e) => e.id === booking.equipmentId);

    // Lifecycle capacity management:
    // When issued: availableQuantity decreases
    if (newStatus === 'issued' && previousStatus !== 'issued') {
      booking.issuedAt = new Date().toISOString();
      if (equipment && equipment.availableQuantity > 0) {
        equipment.availableQuantity = Math.max(0, equipment.availableQuantity - 1);
      }
    }

    // When returned: availableQuantity restores
    if (newStatus === 'returned' && previousStatus === 'issued') {
      booking.returnedAt = new Date().toISOString();
      if (equipment && equipment.availableQuantity < equipment.totalQuantity) {
        equipment.availableQuantity = Math.min(equipment.totalQuantity, equipment.availableQuantity + 1);
      }
    }

    // Notification triggers based on faculty action
    if (newStatus === 'approved') {
      this.addNotification({
        bookingReference: booking.bookingReference,
        title: 'Booking Approved by Faculty',
        message: `Your booking for "${booking.equipmentName}" was approved. ${facultyNotes || 'Please arrive at the lab on schedule with your student ID.'}`,
        type: 'success',
      });
    } else if (newStatus === 'rejected') {
      this.addNotification({
        bookingReference: booking.bookingReference,
        title: 'Booking Rejected',
        message: `Your booking for "${booking.equipmentName}" could not be accommodated. Reason: ${facultyNotes || 'Schedule capacity or prerequisite requirement not satisfied.'}`,
        type: 'alert',
      });
    } else if (newStatus === 'alternative_proposed') {
      this.addNotification({
        bookingReference: booking.bookingReference,
        title: 'Alternative Slot Proposed',
        message: `Faculty proposed an alternative slot for "${booking.equipmentName}". Reason: ${alternativeSlot?.reason || 'Conflict mitigation.'}`,
        type: 'warning',
      });
    } else if (newStatus === 'issued') {
      this.addNotification({
        bookingReference: booking.bookingReference,
        title: 'Equipment Checked Out / Issued',
        message: `"${booking.equipmentName}" is now issued to you. Please handle with care and return before your slot expires.`,
        type: 'info',
      });
    } else if (newStatus === 'returned') {
      this.addNotification({
        bookingReference: booking.bookingReference,
        title: 'Equipment Returned & Cleared',
        message: `Thank you! "${booking.equipmentName}" has been checked in and cleared by the laboratory supervisor.`,
        type: 'success',
      });
    }

    this.persist();
    return booking;
  }

  // Notifications
  public getNotifications(bookingReference?: string): NotificationItem[] {
    if (bookingReference) {
      const clean = bookingReference.trim().toUpperCase();
      return this.state.notifications.filter(
        (n) => n.bookingReference.toUpperCase() === clean
      );
    }
    return [...this.state.notifications];
  }

  public addNotification(notif: Omit<NotificationItem, 'id' | 'createdAt' | 'read'>): NotificationItem {
    const item: NotificationItem = {
      ...notif,
      id: `notif-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      createdAt: new Date().toISOString(),
      read: false,
    };
    this.state.notifications.unshift(item);
    this.persist();
    return item;
  }

  public markNotificationRead(id: string): void {
    const item = this.state.notifications.find((n) => n.id === id);
    if (item) {
      item.read = true;
      this.persist();
    }
  }

  // Department usage metrics
  public getDepartmentUsage(): Record<string, number> {
    return { ...this.state.departmentUsage };
  }

  // Resource Utilisation Analytics
  public getUtilizationMetrics(): UtilizationMetric[] {
    const departments: Department[] = [
      'Computer Science & Engineering',
      'Electronics & Communication',
      'Electrical & Electronics',
      'Mechanical Engineering',
      'Physics & Advanced Materials',
    ];

    return departments.map((dept) => {
      const deptEquip = this.state.equipment.filter((e) => e.department === dept);
      const totalCount = deptEquip.reduce((sum, e) => sum + e.totalQuantity, 0);
      const availableCount = deptEquip.reduce((sum, e) => sum + e.availableQuantity, 0);
      const inUseCount = totalCount - availableCount;
      const utilizationRate = totalCount > 0 ? Math.round((inUseCount / totalCount) * 100) : 0;

      return {
        department: dept,
        totalEquipment: totalCount,
        activeBookings: inUseCount,
        utilizationRate,
        idleEquipmentCount: availableCount,
      };
    });
  }

  // Reset to initial demonstration state (Evaluator Feature I)
  public resetDemoData(): void {
    this.state = {
      equipment: JSON.parse(JSON.stringify(INITIAL_EQUIPMENT)),
      bookings: JSON.parse(JSON.stringify(INITIAL_BOOKINGS)),
      notifications: JSON.parse(JSON.stringify(INITIAL_NOTIFICATIONS)),
      departmentUsage: {
        'Computer Science & Engineering': 4,
        'Electronics & Communication': 3,
        'Electrical & Electronics': 1,
        'Mechanical Engineering': 2,
        'Physics & Advanced Materials': 1,
      },
    };
    this.persist();
  }
}

// Global singleton instance
export const mockDb = new MockDatabaseStore();
