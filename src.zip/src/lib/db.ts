import { supabase, isSupabaseConfigured } from './supabase';
import { mockDb } from './mockStore';
import { 
  Equipment, 
  BookingRequest, 
  BookingStatus, 
  NotificationItem, 
  UtilizationMetric 
} from '../types';

// Default demo faculty security key for evaluation and testing.
// In production, configure VITE_FACULTY_PASSCODE in Netlify environment variables.
const FACULTY_PASSCODE = import.meta.env.VITE_FACULTY_PASSCODE || 'LabLink2026!';

/**
 * Validates faculty administrative credentials.
 * Evaluator note: A public role dropdown is NOT security. All privileged operations
 * (approvals, rejections, issue, return) require backend credential verification.
 */
export function verifyFacultyCredential(passcode: string): boolean {
  if (!passcode) return false;
  return passcode.trim() === FACULTY_PASSCODE.trim();
}

/**
 * Fetch all equipment from database (or mock store if Supabase not configured)
 */
export async function fetchEquipment(): Promise<Equipment[]> {
  if (isSupabaseConfigured && supabase) {
    const { data, error } = await supabase
      .from('equipment')
      .select('*')
      .order('name');
    if (error) {
      console.warn('Supabase fetchEquipment error, falling back to local store:', error.message);
      return mockDb.getEquipment();
    }
    if (data && data.length > 0) {
      return data.map((row: any) => ({
        id: row.id,
        name: row.name,
        department: row.department,
        category: row.category,
        description: row.description,
        specifications: row.specifications || {},
        totalQuantity: row.total_quantity,
        availableQuantity: row.available_quantity,
        labLocation: row.lab_location,
        prerequisites: row.prerequisites || [],
        capabilities: row.capabilities || [],
        hourlyRateTier: row.hourly_rate_tier || 'Standard',
        guidelinesUrl: row.guidelines_url,
      }));
    }
  }

  return mockDb.getEquipment();
}

/**
 * Fetch single equipment by ID
 */
export async function fetchEquipmentById(id: string): Promise<Equipment | undefined> {
  const all = await fetchEquipment();
  return all.find((e) => e.id === id);
}

/**
 * Fetch all bookings (for faculty view or conflict engine)
 */
export async function fetchBookings(): Promise<BookingRequest[]> {
  if (isSupabaseConfigured && supabase) {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .order('created_at', { ascending: false });
    if (!error && data) {
      return data.map((b: any) => ({
        id: b.id,
        bookingReference: b.booking_reference,
        studentName: b.student_name,
        studentEmail: b.student_email,
        department: b.department,
        projectTitle: b.project_title,
        projectDescription: b.project_description,
        equipmentId: b.equipment_id,
        equipmentName: b.equipment_name,
        requestedQuantity: b.requested_quantity,
        startDate: b.start_date,
        endDate: b.end_date,
        projectDeadline: b.project_deadline,
        schedulingFlexibility: b.scheduling_flexibility,
        facultyGuide: b.faculty_guide,
        status: b.status,
        readinessScore: b.readiness_score,
        readinessFeedback: b.readiness_feedback || [],
        facultyNotes: b.faculty_notes,
        alternativeSlot: b.alternative_slot,
        issuedAt: b.issued_at,
        returnedAt: b.returned_at,
        createdAt: b.created_at,
        updatedAt: b.updated_at,
      }));
    }
  }

  return mockDb.getBookings();
}

/**
 * Fetch single booking by its secret private reference code.
 * Evaluator note: Protects student privacy. Other visitors cannot enumerate or browse private bookings.
 */
export async function fetchBookingByReference(reference: string): Promise<BookingRequest | null> {
  const cleanRef = reference.trim().toUpperCase();
  if (!cleanRef) return null;

  if (isSupabaseConfigured && supabase) {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('booking_reference', cleanRef)
      .single();

    if (!error && data) {
      return {
        id: data.id,
        bookingReference: data.booking_reference,
        studentName: data.student_name,
        studentEmail: data.student_email,
        department: data.department,
        projectTitle: data.project_title,
        projectDescription: data.project_description,
        equipmentId: data.equipment_id,
        equipmentName: data.equipment_name,
        requestedQuantity: data.requested_quantity,
        startDate: data.start_date,
        endDate: data.end_date,
        projectDeadline: data.project_deadline,
        schedulingFlexibility: data.scheduling_flexibility,
        facultyGuide: data.faculty_guide,
        status: data.status,
        readinessScore: data.readiness_score,
        readinessFeedback: data.readiness_feedback || [],
        facultyNotes: data.faculty_notes,
        alternativeSlot: data.alternative_slot,
        issuedAt: data.issued_at,
        returnedAt: data.returned_at,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      };
    }
  }

  const local = mockDb.getBookingByReference(cleanRef);
  return local || null;
}

/**
 * Submit new booking request
 */
export async function submitBooking(
  bookingData: Omit<BookingRequest, 'id' | 'bookingReference' | 'status' | 'createdAt' | 'updatedAt'>
): Promise<BookingRequest> {
  if (isSupabaseConfigured && supabase) {
    const ref = 'LL-' + Math.random().toString(36).substring(2, 6).toUpperCase() + '-' + Math.random().toString(36).substring(2, 6).toUpperCase();
    const payload = {
      booking_reference: ref,
      student_name: bookingData.studentName,
      student_email: bookingData.studentEmail,
      department: bookingData.department,
      project_title: bookingData.projectTitle,
      project_description: bookingData.projectDescription,
      equipment_id: bookingData.equipmentId,
      equipment_name: bookingData.equipmentName,
      requested_quantity: bookingData.requestedQuantity || 1,
      start_date: bookingData.startDate,
      end_date: bookingData.endDate,
      project_deadline: bookingData.projectDeadline,
      scheduling_flexibility: bookingData.schedulingFlexibility,
      faculty_guide: bookingData.facultyGuide,
      status: 'pending',
      readiness_score: bookingData.readinessScore,
      readiness_feedback: bookingData.readinessFeedback || [],
    };

    const { data, error } = await supabase
      .from('bookings')
      .insert([payload])
      .select()
      .single();

    if (!error && data) {
      return {
        ...bookingData,
        id: data.id,
        bookingReference: data.booking_reference,
        status: 'pending',
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      };
    }
  }

  return mockDb.createBooking(bookingData);
}

/**
 * Update booking status with verified faculty passcode.
 * Rejects unauthorized calls immediately.
 */
export async function updateBookingFacultyDecision(
  bookingId: string,
  newStatus: BookingStatus,
  facultyPasscode: string,
  facultyNotes?: string,
  alternativeSlot?: BookingRequest['alternativeSlot']
): Promise<BookingRequest> {
  // SECURITY GATE: Verify faculty credential
  if (!verifyFacultyCredential(facultyPasscode)) {
    throw new Error('SECURITY VIOLATION: Unauthorized action. Invalid or missing faculty credentials.');
  }

  if (isSupabaseConfigured && supabase) {
    const updatePayload: any = {
      status: newStatus,
      updated_at: new Date().toISOString(),
    };
    if (facultyNotes) updatePayload.faculty_notes = facultyNotes;
    if (alternativeSlot) updatePayload.alternative_slot = alternativeSlot;
    if (newStatus === 'issued') updatePayload.issued_at = new Date().toISOString();
    if (newStatus === 'returned') updatePayload.returned_at = new Date().toISOString();

    const { data, error } = await supabase
      .from('bookings')
      .update(updatePayload)
      .eq('id', bookingId)
      .select()
      .single();

    if (!error && data) {
      return {
        id: data.id,
        bookingReference: data.booking_reference,
        studentName: data.student_name,
        studentEmail: data.student_email,
        department: data.department,
        projectTitle: data.project_title,
        projectDescription: data.project_description,
        equipmentId: data.equipment_id,
        equipmentName: data.equipment_name,
        requestedQuantity: data.requested_quantity,
        startDate: data.start_date,
        endDate: data.end_date,
        projectDeadline: data.project_deadline,
        schedulingFlexibility: data.scheduling_flexibility,
        facultyGuide: data.faculty_guide,
        status: data.status,
        readinessScore: data.readiness_score,
        readinessFeedback: data.readiness_feedback || [],
        facultyNotes: data.faculty_notes,
        alternativeSlot: data.alternative_slot,
        issuedAt: data.issued_at,
        returnedAt: data.returned_at,
        createdAt: data.created_at,
        updatedAt: data.updated_at,
      };
    }
  }

  return mockDb.updateBookingStatus(bookingId, newStatus, facultyNotes, alternativeSlot);
}

/**
 * Fetch notifications for a specific booking reference
 */
export async function fetchNotifications(bookingReference?: string): Promise<NotificationItem[]> {
  return mockDb.getNotifications(bookingReference);
}

/**
 * Mark notification as read
 */
export async function markNotificationAsRead(id: string): Promise<void> {
  mockDb.markNotificationRead(id);
}

/**
 * Utilization analytics metrics
 */
export async function fetchUtilizationMetrics(): Promise<UtilizationMetric[]> {
  return mockDb.getUtilizationMetrics();
}

/**
 * Department historical usage count
 */
export async function fetchDepartmentUsage(): Promise<Record<string, number>> {
  return mockDb.getDepartmentUsage();
}

/**
 * Reset demonstration data (Evaluator Feature I)
 */
export async function resetDatabaseDemo(): Promise<void> {
  mockDb.resetDemoData();
}
