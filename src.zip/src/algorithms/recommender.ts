import { Equipment, RecommendationMatch, RecommendationResult } from '../types';

/**
 * Transparent, deterministic keyword and capability mapping engine.
 * Maps student project descriptions to laboratory capabilities without blackbox hallucinations.
 */
interface CapabilityRule {
  keywords: string[];
  capability: string;
  weight: number;
}

const CAPABILITY_RULES: CapabilityRule[] = [
  // Deep Learning & AI
  { keywords: ['deep learning', 'neural net', 'llm', 'large language model', 'gpt', 'transformer', 'pytorch', 'tensorflow', 'gpu', 'cuda', 'train model', 'fine tune', 'backprop'], capability: 'deep learning', weight: 1.5 },
  { keywords: ['computer vision', 'opencv', 'object detection', 'yolo', 'image segmentation', 'cnn', 'resnet'], capability: 'computer vision', weight: 1.3 },
  { keywords: ['edge ai', 'tinyml', 'low power ml', 'on-device inference', 'coral', 'edge tpu', 'tflite'], capability: 'edge ai', weight: 1.4 },
  
  // IoT & Embedded
  { keywords: ['iot', 'sensor', 'microcontroller', 'arduino', 'esp32', 'raspberry pi', 'smart irrigation', 'soil moisture', 'embedded', 'telemetry'], capability: 'iot', weight: 1.2 },
  { keywords: ['depth sensing', 'slam', 'lidar', 'point cloud', '3d vision', 'autonomous', 'spatial mapping', 'realsense', 'stereo camera'], capability: 'depth sensing', weight: 1.3 },
  { keywords: ['robotics', 'robot', 'ros', 'manipulator', 'rover', 'actuator', 'drone', 'uav'], capability: 'robotics', weight: 1.2 },

  // Electronics & Signals
  { keywords: ['oscilloscope', 'waveform', 'signal debug', 'clock signal', 'i2c', 'spi', 'uart', 'can bus', 'noise', 'analog signal'], capability: 'oscilloscope', weight: 1.4 },
  { keywords: ['fpga', 'verilog', 'vhdl', 'zynq', 'vivado', 'hardware acceleration', 'logic synthesis', 'custom circuit'], capability: 'fpga', weight: 1.5 },
  { keywords: ['rf', 'spectrum', 'antenna', 'radio frequency', 'wireless', 'lora', '5g', 'wifi', 'emi', 'transmission', 'electromagnetic'], capability: 'rf testing', weight: 1.4 },

  // Power & Energy
  { keywords: ['battery', 'dc load', 'power electronics', 'converter', 'inverter', 'solar', 'photovoltaic', 'bms', 'charging', 'energy storage'], capability: 'power electronics', weight: 1.3 },
  { keywords: ['matlab', 'simulink', 'hil', 'hardware in the loop', 'motor control', 'electric drive', 'bldc', 'pmsm', 'rapid prototyping'], capability: 'hardware in the loop', weight: 1.4 },

  // Fabrication & Mechanical
  { keywords: ['3d print', 'additive manufacturing', 'rapid prototype', 'enclosure', 'chassis', 'filament', 'cad', 'stl', 'housing'], capability: '3d printing', weight: 1.3 },
  { keywords: ['laser cut', 'acrylic', 'engrave', 'sheet cutting', 'bracket', 'precision cutting', 'wood cutting'], capability: 'laser cutting', weight: 1.3 },
  { keywords: ['tensile', 'stress strain', 'material strength', 'compression test', 'yield stress', 'mechanics of materials', 'composite test'], capability: 'tensile testing', weight: 1.4 },

  // Physics & Materials
  { keywords: ['source meter', 'smu', 'iv characterization', 'semiconductor', 'thin film', 'photovoltaic cell', 'keithley', 'resistance', 'nanomaterials', 'graphene'], capability: 'iv characterization', weight: 1.4 },
  { keywords: ['spectroscopy', 'uv vis', 'optical absorption', 'bandgap', 'absorbance', 'spectrophotometer', 'cuvette', 'optical wavelength'], capability: 'spectroscopy', weight: 1.4 },
];

export function recommendEquipmentForProject(
  projectDescription: string,
  projectTitle: string = '',
  catalog: Equipment[]
): RecommendationResult {
  const combinedText = `${projectTitle.toLowerCase()} ${projectDescription.toLowerCase()}`;
  const detectedKeywords: string[] = [];
  const matchedCapabilities = new Set<string>();

  // 1. Identify matched capabilities and keywords from the project text
  for (const rule of CAPABILITY_RULES) {
    for (const kw of rule.keywords) {
      if (combinedText.includes(kw)) {
        if (!detectedKeywords.includes(kw)) {
          detectedKeywords.push(kw);
        }
        matchedCapabilities.add(rule.capability);
      }
    }
  }

  // 2. Score each piece of equipment against detected capabilities and keywords
  const scoredEquipment: RecommendationMatch[] = catalog.map((equipment) => {
    let score = 0;
    const itemMatchedCaps: string[] = [];
    const equipCapabilities = equipment.capabilities.map((c) => c.toLowerCase());

    // Capability overlaps from detected rules
    for (const detectedCap of matchedCapabilities) {
      if (equipCapabilities.some((ec) => ec.includes(detectedCap) || detectedCap.includes(ec))) {
        score += 25;
        if (!itemMatchedCaps.includes(detectedCap)) {
          itemMatchedCaps.push(detectedCap);
        }
      }
    }

    // Direct matches against the equipment's own specific capabilities list
    for (const cap of equipCapabilities) {
      if (combinedText.includes(cap)) {
        score += 18;
        if (!itemMatchedCaps.includes(cap)) {
          itemMatchedCaps.push(cap);
        }
      } else {
        const words = cap.split(/\s+/).filter((w) => w.length > 3);
        for (const w of words) {
          if (combinedText.includes(w)) {
            score += 8;
            if (!itemMatchedCaps.includes(w)) {
              itemMatchedCaps.push(w);
            }
          }
        }
      }
    }

    // Direct text mentions of equipment name or category keywords
    const equipNameWords = equipment.name.toLowerCase().split(/\s+/);
    for (const word of equipNameWords) {
      if (word.length > 3 && combinedText.includes(word)) {
        score += 15;
      }
    }

    // Description overlap with detected keywords
    for (const kw of detectedKeywords) {
      if (equipment.description.toLowerCase().includes(kw)) {
        score += 10;
      }
    }

    // Availability bonus (available units make it more immediately practical)
    if (equipment.availableQuantity > 0) {
      score += 5;
    }

    // Normalize score to max 100
    const normalizedScore = Math.min(Math.round(score), 99);

    // Build transparent explanation
    let explanation = '';
    if (itemMatchedCaps.length > 0) {
      explanation = `Directly supports your project's requirement for ${itemMatchedCaps.join(', ')} with verified laboratory specifications.`;
    } else if (score > 20) {
      explanation = `Related to project scope based on matching domain terms in ${equipment.category}.`;
    } else {
      explanation = `General utility laboratory equipment within ${equipment.department}.`;
    }

    return {
      equipment,
      matchScore: normalizedScore,
      matchedCapabilities: itemMatchedCaps,
      explanation,
      prerequisitesMet: true, // Default advisory flag
      missingPrerequisites: equipment.prerequisites,
    };
  });

  // Filter items that have at least some relevance
  const relevantItems = scoredEquipment
    .filter((item) => item.matchScore >= 25)
    .sort((a, b) => b.matchScore - a.matchScore);

  // If no specific match was found, return top available general development & prototyping tools
  if (relevantItems.length === 0) {
    const fallback = catalog.slice(0, 3).map((eq) => ({
      equipment: eq,
      matchScore: 30,
      matchedCapabilities: ['general laboratory prototyping'],
      explanation: 'General foundational laboratory equipment suitable for exploratory university research projects.',
      prerequisitesMet: true,
      missingPrerequisites: eq.prerequisites,
    }));

    return {
      projectSummary: projectDescription.slice(0, 140) + '...',
      detectedKeywords: detectedKeywords.length ? detectedKeywords : ['general engineering project'],
      primaryRecommendations: fallback.slice(0, 2),
      compatibleAlternatives: fallback.slice(2),
    };
  }

  // Primary recommendations (highest scoring items)
  const primaryRecommendations = relevantItems.slice(0, 3);

  // Compatible alternatives: look for equipment in same category or adjacent departments
  const primaryIds = new Set(primaryRecommendations.map((r) => r.equipment.id));
  const primaryCategories = new Set(primaryRecommendations.map((r) => r.equipment.category));

  const compatibleAlternatives: RecommendationMatch[] = catalog
    .filter((eq) => !primaryIds.has(eq.id) && primaryCategories.has(eq.category))
    .slice(0, 2)
    .map((eq) => ({
      equipment: eq,
      matchScore: Math.max(50, (relevantItems.find((r) => r.equipment.id === eq.id)?.matchScore || 45)),
      matchedCapabilities: eq.capabilities.slice(0, 2),
      explanation: `Compatible alternative in ${eq.category} hosted in ${eq.department} with immediate availability (${eq.availableQuantity} units).`,
      prerequisitesMet: true,
      missingPrerequisites: eq.prerequisites,
      isAlternative: true,
      alternativeReason: `Cross-department alternative that shares functional capabilities with lower scheduling queue time.`,
    }));

  return {
    projectSummary: projectDescription.length > 150 ? projectDescription.slice(0, 147) + '...' : projectDescription,
    detectedKeywords,
    primaryRecommendations,
    compatibleAlternatives,
  };
}
