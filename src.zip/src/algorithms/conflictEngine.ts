import { BookingRequest, ConflictAnalysisResult, ConflictScoreBreakdown, Equipment } from '../types';

/**
 * Checks if two time intervals [startA, endA] and [startB, endB] overlap.
 */
export function doIntervalsOverlap(
  startA: string | number,
  endA: string | number,
  startB: string | number,
  endB: string | number
): boolean {
  const sA = typeof startA === 'string' ? new Date(startA).getTime() : startA;
  const eA = typeof endA === 'string' ? new Date(endA).getTime() : endA;
  const sB = typeof startB === 'string' ? new Date(startB).getTime() : startB;
  const eB = typeof endB === 'string' ? new Date(endB).getTime() : endB;

  return sA < eB && sB < eA;
}

/**
 * Evaluates individual fair-share allocation score for a competing booking request.
 * Total: 100 points
 * 1. Deadline Urgency (Max 40 points)
 * 2. Project Complexity & Equipment Exclusivity (Max 30 points)
 * 3. Cross-Department Fairness & Usage History (Max 30 points)
 */
export function calculateFairShareScore(
  booking: BookingRequest,
  equipment: Equipment,
  departmentUsageCount: Record<string, number> = {}
): ConflictScoreBreakdown {
  const now = Date.now();
  const deadlineTime = new Date(booking.projectDeadline).getTime();
  const daysUntilDeadline = Math.max(0.1, (deadlineTime - now) / (1000 * 60 * 60 * 24));

  // --- 1. Deadline Urgency (Weight: 40%) ---
  // Closer deadline = higher urgency score
  let deadlineUrgencyScore = 0;
  if (daysUntilDeadline <= 2) {
    deadlineUrgencyScore = 40; // Critical imminent deadline
  } else if (daysUntilDeadline <= 5) {
    deadlineUrgencyScore = 34;
  } else if (daysUntilDeadline <= 10) {
    deadlineUrgencyScore = 26;
  } else if (daysUntilDeadline <= 20) {
    deadlineUrgencyScore = 18;
  } else {
    deadlineUrgencyScore = 10;
  }

  // Adjust for student flexibility: if strict, urgency remains; if flexible, small concession
  if (booking.schedulingFlexibility === 'flexible') {
    deadlineUrgencyScore = Math.max(8, deadlineUrgencyScore - 6);
  } else if (booking.schedulingFlexibility === 'moderate') {
    deadlineUrgencyScore = Math.max(8, deadlineUrgencyScore - 2);
  }

  // --- 2. Project Complexity & Equipment Exclusivity (Weight: 30%) ---
  let complexityAndExclusivityScore = 0;

  // Equipment tier factor
  if (equipment.hourlyRateTier === 'Specialized') {
    complexityAndExclusivityScore += 12;
  } else if (equipment.hourlyRateTier === 'High-Demand') {
    complexityAndExclusivityScore += 9;
  } else {
    complexityAndExclusivityScore += 6;
  }

  // Project description depth & readiness
  const words = booking.projectDescription.trim().split(/\s+/).length;
  if (words >= 35) {
    complexityAndExclusivityScore += 10;
  } else if (words >= 20) {
    complexityAndExclusivityScore += 7;
  } else {
    complexityAndExclusivityScore += 4;
  }

  // Readiness factor bonus
  if (booking.readinessScore >= 85) {
    complexityAndExclusivityScore += 8;
  } else if (booking.readinessScore >= 70) {
    complexityAndExclusivityScore += 5;
  } else {
    complexityAndExclusivityScore += 2;
  }

  // Cap complexity at 30
  complexityAndExclusivityScore = Math.min(30, complexityAndExclusivityScore);

  // --- 3. Cross-Department Fairness & Usage History (Weight: 30%) ---
  let departmentFairnessScore = 0;

  // Cross-department incentive: encourages sharing university resources across faculties
  const isCrossDepartment = booking.department !== equipment.department;
  if (isCrossDepartment) {
    // Interdisciplinary project accessing outside laboratory
    departmentFairnessScore += 16;
  } else {
    // Home department request
    departmentFairnessScore += 10;
  }

  // Historical usage balancing (penalize department hoarding, reward underrepresented branches)
  const currentDeptUsage = departmentUsageCount[booking.department] || 0;
  if (currentDeptUsage === 0) {
    departmentFairnessScore += 14; // First-time department access priority
  } else if (currentDeptUsage <= 2) {
    departmentFairnessScore += 10;
  } else if (currentDeptUsage <= 5) {
    departmentFairnessScore += 6;
  } else {
    departmentFairnessScore += 2; // Heavy prior usage
  }

  // Cap department fairness at 30
  departmentFairnessScore = Math.min(30, departmentFairnessScore);

  const totalScore = Math.round(
    deadlineUrgencyScore + complexityAndExclusivityScore + departmentFairnessScore
  );

  const explanation = `Score ${totalScore}/100: Deadline urgency (${deadlineUrgencyScore}/40 pts, deadline in ${daysUntilDeadline.toFixed(1)} days), Technical complexity & readiness (${complexityAndExclusivityScore}/30 pts), Interdisciplinary fairness & usage equity (${departmentFairnessScore}/30 pts).`;

  return {
    deadlineUrgencyScore,
    complexityAndExclusivityScore,
    departmentFairnessScore,
    totalScore,
    explanation,
  };
}

/**
 * Suggests non-overlapping alternative slots shifted earlier, later, or next available morning/afternoon.
 */
export function generateAlternativeSlots(
  conflictingBooking: BookingRequest,
  _occupiedStart: number,
  occupiedEnd: number
): { suggestedStart: string; suggestedEnd: string; reason: string } {
  const reqStart = new Date(conflictingBooking.startDate).getTime();
  const reqEnd = new Date(conflictingBooking.endDate).getTime();
  const durationMs = reqEnd - reqStart;

  // 1. Check if same-day afternoon / evening slot after occupied slot is viable
  const sameDayNextSlotStart = occupiedEnd + 30 * 60 * 1000; // 30 min turnaround buffer
  const sameDayNextSlotEnd = sameDayNextSlotStart + durationMs;
  const sameDayEndDate = new Date(sameDayNextSlotEnd);

  // If slot finishes by 7 PM (19:00), offer same-day adjacent slot
  if (sameDayEndDate.getUTCHours() <= 19) {
    return {
      suggestedStart: new Date(sameDayNextSlotStart).toISOString(),
      suggestedEnd: new Date(sameDayNextSlotEnd).toISOString(),
      reason: 'Adjacent same-day slot immediately following earlier reservation with 30-minute instrument maintenance turnaround.',
    };
  }

  // 2. Otherwise offer next business day morning session (09:00 - 13:00 / requested duration)
  const nextDay = new Date(reqStart + 24 * 60 * 60 * 1000);
  nextDay.setUTCHours(9, 0, 0, 0);
  const nextDayEnd = new Date(nextDay.getTime() + durationMs);

  return {
    suggestedStart: nextDay.toISOString(),
    suggestedEnd: nextDayEnd.toISOString(),
    reason: 'Next-day morning session (09:00 AM) ensuring clean laboratory bench setup and dedicated faculty supervisor presence.',
  };
}

/**
 * Detects conflicts across all active or pending bookings for a target equipment
 * and calculates fair-share recommendations.
 */
export function analyzeEquipmentConflicts(
  targetEquipment: Equipment,
  allBookings: BookingRequest[],
  departmentUsageCount: Record<string, number> = {}
): ConflictAnalysisResult {
  // Filter active, pending, or approved bookings for this specific equipment
  const relevantBookings = allBookings.filter(
    (b) =>
      b.equipmentId === targetEquipment.id &&
      ['pending', 'approved', 'issued'].includes(b.status)
  );

  // Group by overlapping clusters
  const competingPairs: { b1: BookingRequest; b2: BookingRequest }[] = [];

  for (let i = 0; i < relevantBookings.length; i++) {
    for (let j = i + 1; j < relevantBookings.length; j++) {
      const b1 = relevantBookings[i];
      const b2 = relevantBookings[j];

      if (doIntervalsOverlap(b1.startDate, b1.endDate, b2.startDate, b2.endDate)) {
        competingPairs.push({ b1, b2 });
      }
    }
  }

  // If available capacity meets or exceeds total requested units during overlapping periods, no conflict
  if (competingPairs.length === 0) {
    return {
      hasConflict: false,
      equipmentId: targetEquipment.id,
      equipmentName: targetEquipment.name,
      totalAvailable: targetEquipment.availableQuantity,
      competingBookings: [],
      recommendationReason: `No schedule overlap detected. ${targetEquipment.availableQuantity} of ${targetEquipment.totalQuantity} units currently available.`,
      proposedAlternativeSlots: [],
    };
  }

  // Take the primary conflict pair
  const { b1, b2 } = competingPairs[0];
  const score1 = calculateFairShareScore(b1, targetEquipment, departmentUsageCount);
  const score2 = calculateFairShareScore(b2, targetEquipment, departmentUsageCount);

  const competingBookings = [
    { booking: b1, scoreBreakdown: score1 },
    { booking: b2, scoreBreakdown: score2 },
  ].sort((a, b) => b.scoreBreakdown.totalScore - a.scoreBreakdown.totalScore);

  const winner = competingBookings[0];
  const runnerUp = competingBookings[1];

  // Propose alternative slot for the runner-up
  const occupiedStart = new Date(winner.booking.startDate).getTime();
  const occupiedEnd = new Date(winner.booking.endDate).getTime();
  const altSlot = generateAlternativeSlots(runnerUp.booking, occupiedStart, occupiedEnd);

  // Determine split session feasibility if total combined requested duration can fit inside the window
  let splitSessionSuggestion: ConflictAnalysisResult['splitSessionSuggestion'] = undefined;
  const start1 = new Date(b1.startDate).getTime();
  const end1 = new Date(b1.endDate).getTime();
  const start2 = new Date(b2.startDate).getTime();
  const end2 = new Date(b2.endDate).getTime();

  const windowStart = Math.min(start1, start2);
  const windowEnd = Math.max(end1, end2);
  const totalWindowHours = (windowEnd - windowStart) / (1000 * 60 * 60);

  if (totalWindowHours >= 6) {
    const midpoint = windowStart + (windowEnd - windowStart) / 2;
    splitSessionSuggestion = {
      bookingId1: winner.booking.id,
      slot1: {
        start: new Date(windowStart).toISOString(),
        end: new Date(midpoint).toISOString(),
      },
      bookingId2: runnerUp.booking.id,
      slot2: {
        start: new Date(midpoint).toISOString(),
        end: new Date(windowEnd).toISOString(),
      },
      reason: `The requested time span spans ${totalWindowHours.toFixed(1)} hours. The slot can be harmoniously partitioned into two ${(totalWindowHours / 2).toFixed(1)}-hour sub-sessions so both research milestones proceed without delay.`,
    };
  }

  const recommendationReason = `${winner.booking.studentName} is prioritized (Score: ${winner.scoreBreakdown.totalScore} vs ${runnerUp.scoreBreakdown.totalScore}) due to ${
    winner.scoreBreakdown.deadlineUrgencyScore > runnerUp.scoreBreakdown.deadlineUrgencyScore
      ? 'imminent project submission deadline urgency'
      : 'higher project technical complexity & interdepartmental equity'
  }. Alternative slot proposed for ${runnerUp.booking.studentName} without cancelling their request.`;

  return {
    hasConflict: true,
    equipmentId: targetEquipment.id,
    equipmentName: targetEquipment.name,
    totalAvailable: targetEquipment.availableQuantity,
    competingBookings,
    recommendedWinnerId: winner.booking.id,
    recommendationReason,
    proposedAlternativeSlots: [
      {
        bookingId: runnerUp.booking.id,
        studentName: runnerUp.booking.studentName,
        suggestedStart: altSlot.suggestedStart,
        suggestedEnd: altSlot.suggestedEnd,
        reason: altSlot.reason,
      },
    ],
    splitSessionSuggestion,
  };
}
