import { Equipment, ReadinessEvaluation } from '../types';

export interface BookingFormData {
  studentName: string;
  studentEmail: string;
  department: string;
  projectTitle: string;
  projectDescription: string;
  equipmentId: string;
  startDate: string;
  endDate: string;
  projectDeadline: string;
  schedulingFlexibility: 'strict' | 'moderate' | 'flexible';
  facultyGuide?: string;
}

/**
 * Deterministic Project Readiness Scoring Engine.
 * Evaluates whether a laboratory booking submission is complete, well-justified,
 * and operationally feasible before faculty review.
 */
export function evaluateBookingReadiness(
  formData: BookingFormData,
  selectedEquipment?: Equipment | null
): ReadinessEvaluation {
  let score = 0;
  const missingFields: string[] = [];
  const suggestions: string[] = [];

  // 1. Basic Identity & Department (Max 15 pts)
  if (formData.studentName.trim().length >= 3) {
    score += 5;
  } else {
    missingFields.push('Student Name');
  }

  if (formData.studentEmail.trim().includes('@') && formData.studentEmail.trim().length > 5) {
    score += 5;
  } else {
    missingFields.push('Valid University Email');
  }

  if (formData.department && formData.department.trim().length > 0) {
    score += 5;
  } else {
    missingFields.push('Department / Branch');
  }

  // 2. Project Title & Detailed Description Completeness (Max 30 pts)
  if (formData.projectTitle.trim().length >= 8) {
    score += 10;
  } else {
    missingFields.push('Descriptive Project Title (at least 8 characters)');
    suggestions.push('Provide a clear, specific project title (e.g. "Edge AI Camera for Precision Agriculture").');
  }

  const descWordCount = formData.projectDescription.trim().split(/\s+/).filter(Boolean).length;
  if (descWordCount >= 30) {
    score += 20;
  } else if (descWordCount >= 15) {
    score += 12;
    suggestions.push(`Expand project description (currently ${descWordCount} words; aim for 30+ words detailing methodology and required test metrics).`);
  } else if (descWordCount > 0) {
    score += 5;
    suggestions.push('Project description is too brief. Explain what you plan to measure, build, or verify on this equipment.');
  } else {
    missingFields.push('Project Description and Technical Scope');
  }

  // 3. Equipment Selection & Prerequisite Alignment (Max 15 pts)
  if (formData.equipmentId && selectedEquipment) {
    score += 10;
    // Check if equipment has prerequisites
    if (selectedEquipment.prerequisites && selectedEquipment.prerequisites.length > 0) {
      score += 5;
      suggestions.push(`Notice: Equipment requires prerequisites: "${selectedEquipment.prerequisites.join(', ')}". Faculty will verify during approval.`);
    } else {
      score += 5;
    }
  } else {
    missingFields.push('Equipment Selection');
  }

  // 4. Time Window & Feasibility (Max 25 pts)
  if (formData.startDate && formData.endDate) {
    const start = new Date(formData.startDate).getTime();
    const end = new Date(formData.endDate).getTime();
    const durationHours = (end - start) / (1000 * 60 * 60);

    if (end > start) {
      if (durationHours > 0 && durationHours <= 8) {
        score += 15; // Realistic single-day session
      } else if (durationHours > 8 && durationHours <= 72) {
        score += 10;
        suggestions.push(`Requested slot is ${durationHours.toFixed(1)} hours. Extended continuous bookings may require multi-session approval.`);
      } else {
        score += 5;
        suggestions.push('Requested duration exceeds 72 hours. Consider breaking your laboratory test into discrete milestone sessions.');
      }
    } else {
      missingFields.push('Valid Time Slot (End date must be after Start date)');
    }
  } else {
    missingFields.push('Booking Start and End Time Slots');
  }

  // 5. Project Deadline Proximity & Scheduling Flexibility (Max 15 pts)
  if (formData.projectDeadline) {
    const deadline = new Date(formData.projectDeadline).getTime();
    const now = Date.now();
    const daysUntilDeadline = (deadline - now) / (1000 * 60 * 60 * 24);

    if (daysUntilDeadline > 1) {
      score += 5;
      if (formData.startDate) {
        const start = new Date(formData.startDate).getTime();
        if (deadline < start) {
          suggestions.push('Warning: Project submission deadline is earlier than the requested lab slot!');
        }
      }
    } else {
      suggestions.push('Project deadline is within 24 hours. Emergency rush requests are subject to manual lab superintendent approval.');
    }
  } else {
    missingFields.push('Project Milestone / Submission Deadline');
  }

  if (formData.schedulingFlexibility === 'flexible') {
    score += 5;
  } else if (formData.schedulingFlexibility === 'moderate') {
    score += 3;
  } else {
    score += 2;
  }

  if (formData.facultyGuide && formData.facultyGuide.trim().length >= 3) {
    score += 5;
  } else {
    suggestions.push('Tip: Mentioning an endorsing Faculty Guide / Supervisor accelerates departmental approval.');
  }

  // Cap at 100
  const finalScore = Math.min(Math.max(score, 0), 100);

  let level: ReadinessEvaluation['level'] = 'Needs Improvement';
  if (finalScore >= 80) {
    level = 'High';
  } else if (finalScore >= 55) {
    level = 'Moderate';
  }

  const isReadyForSubmission = missingFields.length === 0 && finalScore >= 50;

  // Faculty summary generator
  const equipmentName = selectedEquipment?.name || 'Unspecified Equipment';
  const flexibilityLabel = formData.schedulingFlexibility || 'unspecified';
  const facultySummary = `Request for ${equipmentName} by ${formData.studentName || 'Student'} (${formData.department || 'General'}). Title: "${formData.projectTitle || 'Untitled'}". Readiness: ${finalScore}/100. Flexibility: ${flexibilityLabel}. Safety and prerequisite verification required by authorized faculty prior to issue.`;

  return {
    score: finalScore,
    level,
    missingFields,
    suggestions,
    facultySummary,
    isReadyForSubmission,
  };
}
