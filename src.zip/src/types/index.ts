export type Department = 
  | 'Computer Science & Engineering'
  | 'Electronics & Communication'
  | 'Electrical & Electronics'
  | 'Mechanical Engineering'
  | 'Physics & Advanced Materials';

export type EquipmentCategory = 
  | 'Development Kits & Embedded'
  | 'Test & Measurement'
  | 'Fabrication & Prototyping'
  | 'Computing & AI Workstations'
  | 'Optical & Spectroscopy'
  | 'Robotics & Automation';

export type EquipmentStatus = 'available' | 'reserved' | 'issued' | 'maintenance';

export interface Equipment {
  id: string;
  name: string;
  department: Department;
  category: EquipmentCategory;
  description: string;
  specifications: Record<string, string>;
  totalQuantity: number;
  availableQuantity: number;
  labLocation: string;
  prerequisites: string[];
  imageUrl?: string;
  capabilities: string[];
  hourlyRateTier: 'Standard' | 'High-Demand' | 'Specialized';
  guidelinesUrl?: string;
  maintenanceNote?: string;
}

export type BookingStatus = 
  | 'pending'
  | 'approved'
  | 'rejected'
  | 'alternative_proposed'
  | 'issued'
  | 'returned'
  | 'cancelled';

export interface BookingRequest {
  id: string;
  bookingReference: string; // Unpredictable token e.g. "LL-8F42-99B1"
  studentName: string;
  studentEmail: string;
  department: Department;
  projectTitle: string;
  projectDescription: string;
  equipmentId: string;
  equipmentName: string;
  requestedQuantity: number;
  startDate: string; // ISO string e.g. "2026-11-25T09:00:00Z"
  endDate: string;   // ISO string e.g. "2026-11-25T13:00:00Z"
  projectDeadline: string; // ISO string
  schedulingFlexibility: 'strict' | 'moderate' | 'flexible';
  facultyGuide?: string;
  status: BookingStatus;
  readinessScore: number;
  readinessFeedback?: string[];
  facultyNotes?: string;
  alternativeSlot?: {
    startDate: string;
    endDate: string;
    reason: string;
  };
  issuedAt?: string;
  returnedAt?: string;
  createdAt: string;
  updatedAt: string;
}

export interface RecommendationMatch {
  equipment: Equipment;
  matchScore: number; // 0 to 100
  matchedCapabilities: string[];
  explanation: string;
  prerequisitesMet: boolean;
  missingPrerequisites: string[];
  isAlternative?: boolean;
  alternativeReason?: string;
}

export interface RecommendationResult {
  projectSummary: string;
  detectedKeywords: string[];
  primaryRecommendations: RecommendationMatch[];
  compatibleAlternatives: RecommendationMatch[];
}

export interface ConflictScoreBreakdown {
  deadlineUrgencyScore: number; // Max 40
  complexityAndExclusivityScore: number; // Max 30
  departmentFairnessScore: number; // Max 30
  totalScore: number; // Max 100
  explanation: string;
}

export interface ConflictAnalysisResult {
  hasConflict: boolean;
  equipmentId: string;
  equipmentName: string;
  totalAvailable: number;
  competingBookings: {
    booking: BookingRequest;
    scoreBreakdown: ConflictScoreBreakdown;
  }[];
  recommendedWinnerId?: string;
  recommendationReason: string;
  proposedAlternativeSlots: {
    bookingId: string;
    studentName: string;
    suggestedStart: string;
    suggestedEnd: string;
    reason: string;
  }[];
  splitSessionSuggestion?: {
    bookingId1: string;
    slot1: { start: string; end: string };
    bookingId2: string;
    slot2: { start: string; end: string };
    reason: string;
  };
}

export interface ReadinessEvaluation {
  score: number; // 0-100
  level: 'High' | 'Moderate' | 'Needs Improvement';
  missingFields: string[];
  suggestions: string[];
  facultySummary: string;
  isReadyForSubmission: boolean;
}

export interface NotificationItem {
  id: string;
  bookingReference: string;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'alert';
  createdAt: string;
  read: boolean;
}

export interface UtilizationMetric {
  department: Department;
  totalEquipment: number;
  activeBookings: number;
  utilizationRate: number; // Percentage
  idleEquipmentCount: number;
}
