import React, { useState } from 'react';
import { 
  TerminalSquare, 
  X, 
  Scale, 
  Sparkles, 
  RotateCcw, 
  CheckCircle2, 
  ArrowRight, 
  ShieldAlert, 
  Play 
} from 'lucide-react';
import { Equipment, BookingRequest } from '../types';
import { analyzeEquipmentConflicts } from '../algorithms/conflictEngine';
import { recommendEquipmentForProject } from '../algorithms/recommender';
import { resetDatabaseDemo } from '../lib/db';

interface EvaluatorDemoConsoleProps {
  isOpen: boolean;
  onClose: () => void;
  equipmentList: Equipment[];
  bookingsList: BookingRequest[];
  departmentUsage: Record<string, number>;
  onResetComplete: () => void;
}

export const EvaluatorDemoConsole: React.FC<EvaluatorDemoConsoleProps> = ({
  isOpen,
  onClose,
  equipmentList,
  bookingsList,
  departmentUsage,
  onResetComplete,
}) => {
  const [activeTest, setActiveTest] = useState<'conflict' | 'recommender' | null>(null);
  const [conflictOutput, setConflictOutput] = useState<any>(null);
  const [recommenderOutput, setRecommenderOutput] = useState<any>(null);
  const [resetConfirmOpen, setResetConfirmOpen] = useState(false);
  const [resetSuccess, setResetSuccess] = useState(false);

  if (!isOpen) return null;

  // Action 1: Test Scheduling Conflict
  const handleRunConflictTest = () => {
    // Find target equipment with competing bookings (A100 AI Workstation)
    const target = equipmentList.find((e) => e.name.includes('A100')) || equipmentList[0];
    const result = analyzeEquipmentConflicts(target, bookingsList, departmentUsage);
    setConflictOutput(result);
    setActiveTest('conflict');
  };

  // Action 2: Test Project Recommendation
  const handleRunRecommenderTest = () => {
    const testPrompt = 'I am building an autonomous agricultural robot using depth cameras, ROS, and computer vision to navigate orchard rows.';
    const result = recommendEquipmentForProject(testPrompt, 'Autonomous Orchard Robot', equipmentList);
    setRecommenderOutput(result);
    setActiveTest('recommender');
  };

  // Action 3: Reset Demo Data with Confirmation
  const handleExecuteReset = async () => {
    await resetDatabaseDemo();
    setResetConfirmOpen(false);
    setResetSuccess(true);
    onResetComplete();
    setTimeout(() => setResetSuccess(false), 3000);
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="demo-console-title"
    >
      <div className="bg-slate-900 text-slate-100 rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-slate-700 my-8 space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-violet-500/20 text-violet-400 border border-violet-500/30">
              <TerminalSquare className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 id="demo-console-title" className="text-lg font-bold text-white">
                  Evaluator Interactive Verification Console
                </h2>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                  Live Engine
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Execute live algorithm test vectors and inspect explainable reasoning.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            aria-label="Close demo console"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* 3 Genuine Actions Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Action 1 */}
          <button
            onClick={handleRunConflictTest}
            className="flex flex-col items-start p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 hover:border-primary-500 transition-all text-left group"
          >
            <div className="flex items-center gap-2 text-xs font-bold text-primary-400 mb-1">
              <Scale className="w-4 h-4" />
              <span>1. Run Conflict Test</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Triggers multi-factor contention engine on A100 GPU booking collision.
            </p>
            <div className="mt-2 text-[10px] text-primary-300 font-semibold group-hover:underline flex items-center gap-1">
              <span>Execute Live</span>
              <Play className="w-2.5 h-2.5" />
            </div>
          </button>

          {/* Action 2 */}
          <button
            onClick={handleRunRecommenderTest}
            className="flex flex-col items-start p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 hover:border-violet-500 transition-all text-left group"
          >
            <div className="flex items-center gap-2 text-xs font-bold text-violet-400 mb-1">
              <Sparkles className="w-4 h-4" />
              <span>2. Test Recommender</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Tests natural language matching for autonomous robotics prompt.
            </p>
            <div className="mt-2 text-[10px] text-violet-300 font-semibold group-hover:underline flex items-center gap-1">
              <span>Execute Live</span>
              <Play className="w-2.5 h-2.5" />
            </div>
          </button>

          {/* Action 3 */}
          <button
            onClick={() => setResetConfirmOpen(true)}
            className="flex flex-col items-start p-3.5 rounded-xl bg-slate-800/80 hover:bg-slate-800 border border-slate-700 hover:border-rose-500 transition-all text-left group"
          >
            <div className="flex items-center gap-2 text-xs font-bold text-rose-400 mb-1">
              <RotateCcw className="w-4 h-4" />
              <span>3. Reset Demo Data</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-snug">
              Restores clean initial laboratory state with baseline conflicts.
            </p>
            <div className="mt-2 text-[10px] text-rose-300 font-semibold group-hover:underline flex items-center gap-1">
              <span>Reset State</span>
              <ArrowRight className="w-2.5 h-2.5" />
            </div>
          </button>
        </div>

        {/* Reset Confirmation Prompt */}
        {resetConfirmOpen && (
          <div className="p-4 rounded-xl bg-rose-950/40 border border-rose-800 text-xs space-y-3 animate-in fade-in">
            <div className="flex items-center gap-2 text-rose-300 font-bold">
              <ShieldAlert className="w-4 h-4 text-rose-400" />
              <span>Confirm Demonstration Database Reset</span>
            </div>
            <p className="text-slate-300">
              This will restore the 13 baseline instruments, 4 initial demonstration bookings, and standard
              department usage quotas. Custom user submissions made during this session will be refreshed.
            </p>
            <div className="flex items-center gap-2 pt-1">
              <button
                onClick={handleExecuteReset}
                className="px-3.5 py-1.5 bg-rose-600 hover:bg-rose-700 text-white font-semibold rounded-lg text-xs"
              >
                Yes, Reset Database
              </button>
              <button
                onClick={() => setResetConfirmOpen(false)}
                className="px-3 py-1.5 text-slate-400 hover:text-white text-xs"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {resetSuccess && (
          <div className="p-3 bg-emerald-950/40 border border-emerald-800 rounded-xl text-xs text-emerald-300 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Demonstration state successfully re-initialized with clean seed records.</span>
          </div>
        )}

        {/* Live Output Section */}
        {activeTest === 'conflict' && conflictOutput && (
          <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2">
              <span className="text-primary-400 font-bold">CONFLICT_ENGINE_EXECUTION_TRACE</span>
              <span className="text-emerald-400">STATUS: CONFLICT_RESOLVED</span>
            </div>

            <div className="space-y-1 text-slate-300">
              <p>Target Equipment: <span className="text-white font-semibold">{conflictOutput.equipmentName}</span></p>
              <p>Detected Overlapping Requests: <span className="text-amber-400 font-bold">{conflictOutput.competingBookings.length}</span></p>
            </div>

            <div className="space-y-2 pt-2 border-t border-slate-800">
              <span className="text-slate-400 font-semibold block">COMPETING_REQUESTS_SCORING:</span>
              {conflictOutput.competingBookings.map((comp: any) => (
                <div key={comp.booking.id} className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 text-[11px] space-y-1">
                  <div className="flex justify-between text-white font-bold">
                    <span>{comp.booking.studentName} ({comp.booking.bookingReference})</span>
                    <span className="text-primary-400">Score: {comp.scoreBreakdown.totalScore}/100</span>
                  </div>
                  <div className="text-slate-400 text-[10px]">
                    Urgency (40%): {comp.scoreBreakdown.deadlineUrgencyScore} | Complexity (30%): {comp.scoreBreakdown.complexityAndExclusivityScore} | Equity (30%): {comp.scoreBreakdown.departmentFairnessScore}
                  </div>
                  <div className="text-slate-300 text-[10px]">
                    {comp.scoreBreakdown.explanation}
                  </div>
                </div>
              ))}
            </div>

            <div className="p-2.5 rounded-lg bg-emerald-950/30 border border-emerald-900 text-emerald-200 text-[11px] space-y-1">
              <span className="font-bold">VERDICT & MITIGATION:</span>
              <p>{conflictOutput.recommendationReason}</p>
            </div>
          </div>
        )}

        {activeTest === 'recommender' && recommenderOutput && (
          <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 space-y-3 font-mono text-xs">
            <div className="flex items-center justify-between text-slate-400 border-b border-slate-800 pb-2">
              <span className="text-violet-400 font-bold">RECOMMENDER_CAPABILITY_TRACE</span>
              <span className="text-emerald-400">STATUS: MATCHED</span>
            </div>

            <p className="text-slate-300 text-[11px]">
              Prompt: "Autonomous Orchard Robot (depth cameras, ROS, CV)"
            </p>

            <div className="flex flex-wrap gap-1 text-[10px]">
              <span className="text-slate-400">Detected Keywords:</span>
              {recommenderOutput.detectedKeywords.map((k: string) => (
                <span key={k} className="px-1.5 py-0.5 rounded bg-violet-900/60 text-violet-300">
                  {k}
                </span>
              ))}
            </div>

            <div className="space-y-1.5 pt-1">
              <span className="text-slate-400 font-semibold block text-[11px]">TOP_RECOMMENDED_HARDWARE:</span>
              {recommenderOutput.primaryRecommendations.map((match: any) => (
                <div key={match.equipment.id} className="p-2 rounded bg-slate-900 border border-slate-800 text-[11px] flex items-center justify-between">
                  <div>
                    <span className="text-white font-bold">{match.equipment.name}</span>
                    <span className="text-slate-400 text-[10px] ml-2">({match.equipment.department})</span>
                    <p className="text-slate-400 text-[10px]">{match.explanation}</p>
                  </div>
                  <span className="text-emerald-400 font-bold ml-2 shrink-0">{match.matchScore}% Match</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
