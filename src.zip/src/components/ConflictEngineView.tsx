import React, { useState, useMemo } from 'react';
import { 
  Scale, 
  AlertTriangle, 
  CheckCircle2, 
  Clock, 
  Split, 
  Sparkles, 
  Building2, 
  ShieldCheck
} from 'lucide-react';
import { Equipment, BookingRequest } from '../types';
import { analyzeEquipmentConflicts } from '../algorithms/conflictEngine';

interface ConflictEngineViewProps {
  equipmentList: Equipment[];
  bookingsList: BookingRequest[];
  departmentUsage: Record<string, number>;
  onNavigateToFaculty: () => void;
}

export const ConflictEngineView: React.FC<ConflictEngineViewProps> = ({
  equipmentList,
  bookingsList,
  departmentUsage,
  onNavigateToFaculty,
}) => {
  // Let the user select which equipment to inspect for conflicts (defaults to the A100 GPU which has competing requests)
  const defaultEquipId = equipmentList.find((e) => e.name.includes('A100'))?.id || equipmentList[0]?.id;
  const [selectedEquipId, setSelectedEquipId] = useState<string>(defaultEquipId || '');

  const selectedEquipment = useMemo(() => {
    return equipmentList.find((e) => e.id === selectedEquipId) || equipmentList[0];
  }, [equipmentList, selectedEquipId]);

  // Run the conflict algorithm deterministically
  const conflictAnalysis = useMemo(() => {
    if (!selectedEquipment) return null;
    return analyzeEquipmentConflicts(selectedEquipment, bookingsList, departmentUsage);
  }, [selectedEquipment, bookingsList, departmentUsage]);

  return (
    <div className="space-y-6">
      {/* Hero header */}
      <div className="bg-gradient-to-r from-navy-900 via-primary-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white border border-navy-800 shadow-xl">
        <div className="max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-500/20 text-primary-200 text-xs font-semibold border border-primary-400/30">
            <Scale className="w-3.5 h-3.5 text-primary-300" />
            <span>Flagship Intelligent Allocation Engine</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Smart Fair-Share Conflict Engine
          </h1>
          <p className="text-slate-300 text-sm leading-relaxed">
            Eliminates scheduling gridlocks through transparent, multi-objective fairness optimization.
            When concurrent bookings exceed physical capacity, our engine evaluates deadline urgency (40%),
            project complexity & exclusivity (30%), and inter-department equity (30%) to generate non-destructive resolutions.
          </p>
        </div>
      </div>

      {/* Equipment Selector */}
      <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="space-y-1">
          <label htmlFor="conflict-equip-select" className="text-xs font-bold uppercase tracking-wider text-slate-500 block">
            Inspect Schedule & Contention for Instrument:
          </label>
          <div className="flex items-center gap-2">
            <select
              id="conflict-equip-select"
              value={selectedEquipId}
              onChange={(e) => setSelectedEquipId(e.target.value)}
              className="px-3.5 py-2 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm font-semibold text-slate-800 bg-white outline-hidden cursor-pointer"
            >
              {equipmentList.map((eq) => (
                <option key={eq.id} value={eq.id}>
                  {eq.name} ({eq.department})
                </option>
              ))}
            </select>
            <span className="text-xs text-slate-500">
              Capacity: {selectedEquipment?.availableQuantity} / {selectedEquipment?.totalQuantity} units
            </span>
          </div>
        </div>

        <button
          onClick={onNavigateToFaculty}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-semibold text-xs transition-colors shadow-xs"
        >
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>Review in Faculty Portal</span>
        </button>
      </div>

      {/* Analysis Output */}
      {conflictAnalysis && (
        <div className="space-y-6">
          {conflictAnalysis.hasConflict ? (
            /* Active Contention Card */
            <div className="bg-white rounded-2xl border-2 border-amber-300 p-6 shadow-sm space-y-6">
              {/* Contention Header */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-amber-100 text-amber-800">
                    <AlertTriangle className="w-6 h-6" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                      <span>Concurrent Schedule Conflict Detected</span>
                      <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800">
                        {conflictAnalysis.competingBookings.length} Competing Requests
                      </span>
                    </h2>
                    <p className="text-xs text-slate-500 mt-0.5">
                      Both applicants requested overlapping laboratory time slots exceeding available instrument units.
                    </p>
                  </div>
                </div>

                <div className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700">
                  Target: {conflictAnalysis.equipmentName}
                </div>
              </div>

              {/* Competing Applicants Comparison Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                {conflictAnalysis.competingBookings.map((comp) => {
                  const isWinner = comp.booking.id === conflictAnalysis.recommendedWinnerId;
                  const breakdown = comp.scoreBreakdown;

                  return (
                    <div
                      key={comp.booking.id}
                      className={`rounded-2xl p-5 border-2 transition-all flex flex-col justify-between space-y-4 ${
                        isWinner
                          ? 'border-emerald-500 bg-emerald-50/20 shadow-md'
                          : 'border-slate-300 bg-slate-50/50'
                      }`}
                    >
                      <div className="space-y-3">
                        {/* Winner/Runner-up Header badge */}
                        <div className="flex items-center justify-between">
                          <span className={`text-xs font-extrabold px-2.5 py-1 rounded-full uppercase tracking-wider ${
                            isWinner
                              ? 'bg-emerald-600 text-white'
                              : 'bg-slate-200 text-slate-700'
                          }`}>
                            {isWinner ? '★ Primary Recommendation' : 'Secondary (Alternative Slot)'}
                          </span>
                          <span className="text-xs font-mono text-slate-500">
                            {comp.booking.bookingReference}
                          </span>
                        </div>

                        {/* Student Details */}
                        <div>
                          <h3 className="font-bold text-base text-slate-900">
                            {comp.booking.studentName}
                          </h3>
                          <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-0.5">
                            <Building2 className="w-3.5 h-3.5" />
                            <span>{comp.booking.department}</span>
                          </div>
                        </div>

                        {/* Project Title */}
                        <div className="text-xs text-slate-700 bg-white p-2.5 rounded-xl border border-slate-200/80">
                          <span className="font-semibold block text-slate-900 mb-0.5">"{comp.booking.projectTitle}"</span>
                          <span className="text-slate-500 line-clamp-2">{comp.booking.projectDescription}</span>
                        </div>

                        {/* Timing */}
                        <div className="grid grid-cols-2 gap-2 text-xs pt-1">
                          <div className="space-y-0.5">
                            <span className="text-[10px] font-bold uppercase text-slate-400">Requested Slot:</span>
                            <p className="font-medium text-slate-800">
                              {new Date(comp.booking.startDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - {new Date(comp.booking.endDate).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </p>
                          </div>
                          <div className="space-y-0.5">
                            <span className="text-[10px] font-bold uppercase text-slate-400">Milestone Deadline:</span>
                            <p className="font-bold text-rose-600">
                              {comp.booking.projectDeadline}
                            </p>
                          </div>
                        </div>

                        {/* Transparent Mathematical Score Breakdown */}
                        <div className="bg-white p-3 rounded-xl border border-slate-200 space-y-2 text-xs">
                          <div className="flex items-center justify-between font-bold text-slate-900">
                            <span>Fair-Share Allocation Score:</span>
                            <span className={`text-sm ${isWinner ? 'text-emerald-600 font-extrabold' : 'text-slate-700'}`}>
                              {breakdown.totalScore} / 100
                            </span>
                          </div>

                          {/* 3 Weighted Dimensions */}
                          <div className="space-y-1.5 pt-1">
                            <div>
                              <div className="flex justify-between text-[11px] text-slate-600 mb-0.5">
                                <span>Deadline Urgency (40% Weight):</span>
                                <span className="font-semibold">{breakdown.deadlineUrgencyScore} / 40</span>
                              </div>
                              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                <div className="bg-rose-500 h-full" style={{ width: `${(breakdown.deadlineUrgencyScore / 40) * 100}%` }} />
                              </div>
                            </div>

                            <div>
                              <div className="flex justify-between text-[11px] text-slate-600 mb-0.5">
                                <span>Complexity & Exclusivity (30% Weight):</span>
                                <span className="font-semibold">{breakdown.complexityAndExclusivityScore} / 30</span>
                              </div>
                              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                <div className="bg-primary-500 h-full" style={{ width: `${(breakdown.complexityAndExclusivityScore / 30) * 100}%` }} />
                              </div>
                            </div>

                            <div>
                              <div className="flex justify-between text-[11px] text-slate-600 mb-0.5">
                                <span>Inter-Dept Equity (30% Weight):</span>
                                <span className="font-semibold">{breakdown.departmentFairnessScore} / 30</span>
                              </div>
                              <div className="w-full bg-slate-100 h-1.5 rounded-full overflow-hidden">
                                <div className="bg-teal-500 h-full" style={{ width: `${(breakdown.departmentFairnessScore / 30) * 100}%` }} />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="text-[11px] text-slate-500 italic pt-1">
                        Flexibility declared: <strong className="capitalize">{comp.booking.schedulingFlexibility}</strong>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Engine Transparent Reasoning Box */}
              <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl space-y-2">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-primary-600" />
                  <span>Explainable Allocation Verdict</span>
                </span>
                <p className="text-sm text-slate-800 leading-relaxed font-medium">
                  {conflictAnalysis.recommendationReason}
                </p>
              </div>

              {/* Intelligent Alternative Slot Solutions */}
              {conflictAnalysis.proposedAlternativeSlots.length > 0 && (
                <div className="space-y-3 pt-2 border-t border-slate-100">
                  <span className="text-xs font-bold uppercase tracking-wider text-slate-700 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-violet-600" />
                    <span>Non-Destructive Alternative Slot Recommendation</span>
                  </span>

                  <div className="grid grid-cols-1 gap-3">
                    {conflictAnalysis.proposedAlternativeSlots.map((alt, i) => (
                      <div
                        key={i}
                        className="p-4 rounded-xl border border-violet-200 bg-violet-50/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs"
                      >
                        <div className="space-y-1">
                          <span className="font-bold text-violet-900">
                            Suggested Alternate Time Window for {alt.studentName}:
                          </span>
                          <p className="text-slate-800 font-semibold">
                            {new Date(alt.suggestedStart).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })} — {new Date(alt.suggestedEnd).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </p>
                          <p className="text-slate-600 text-[11px]">
                            {alt.reason}
                          </p>
                        </div>
                        <span className="text-[11px] font-semibold text-violet-700 bg-violet-100 px-3 py-1 rounded-md shrink-0">
                          Zero-Collision Slot
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Split Session Suggestion */}
              {conflictAnalysis.splitSessionSuggestion && (
                <div className="p-4 rounded-xl border border-teal-200 bg-teal-50/30 space-y-2 text-xs">
                  <span className="font-bold uppercase tracking-wider text-teal-800 flex items-center gap-1.5">
                    <Split className="w-4 h-4 text-teal-600" />
                    <span>Optional Split-Session Synthesis</span>
                  </span>
                  <p className="text-slate-700 leading-relaxed">
                    {conflictAnalysis.splitSessionSuggestion.reason}
                  </p>
                </div>
              )}
            </div>
          ) : (
            /* No Conflict State */
            <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center space-y-3">
              <div className="w-12 h-12 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <h2 className="text-base font-bold text-slate-800">
                Optimal Laboratory Capacity — No Schedule Collisions
              </h2>
              <p className="text-xs text-slate-500 max-w-md mx-auto">
                {conflictAnalysis.recommendationReason}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
