import React, { useMemo } from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Layers, 
  CheckCircle2, 
  Clock, 
  Activity
} from 'lucide-react';
import { Equipment, BookingRequest, UtilizationMetric } from '../types';

interface AnalyticsDashboardProps {
  equipmentList: Equipment[];
  bookingsList: BookingRequest[];
  metrics: UtilizationMetric[];
}

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({
  equipmentList,
  bookingsList,
  metrics,
}) => {
  // Aggregate KPIs
  const totalEquipmentUnits = useMemo(() => {
    return equipmentList.reduce((sum, e) => sum + e.totalQuantity, 0);
  }, [equipmentList]);

  const currentlyIssuedUnits = useMemo(() => {
    return equipmentList.reduce((sum, e) => sum + (e.totalQuantity - e.availableQuantity), 0);
  }, [equipmentList]);

  const overallUtilizationPct = totalEquipmentUnits > 0
    ? Math.round((currentlyIssuedUnits / totalEquipmentUnits) * 100)
    : 0;

  const pendingRequestsCount = useMemo(() => {
    return bookingsList.filter((b) => b.status === 'pending').length;
  }, [bookingsList]);

  // Most requested equipment count
  const equipmentRequestCounts = useMemo(() => {
    const counts: Record<string, { name: string; dept: string; count: number }> = {};
    for (const b of bookingsList) {
      if (!counts[b.equipmentId]) {
        counts[b.equipmentId] = { name: b.equipmentName, dept: b.department, count: 0 };
      }
      counts[b.equipmentId].count += 1;
    }
    return Object.values(counts).sort((a, b) => b.count - a.count).slice(0, 5);
  }, [bookingsList]);

  // Department distribution
  const deptBreakdown = useMemo(() => {
    return metrics.map((m) => {
      let color = 'bg-primary-500';
      if (m.department.includes('Electronics')) color = 'bg-violet-500';
      if (m.department.includes('Electrical')) color = 'bg-amber-500';
      if (m.department.includes('Mechanical')) color = 'bg-emerald-500';
      if (m.department.includes('Physics')) color = 'bg-teal-500';

      return {
        ...m,
        barColor: color,
      };
    });
  }, [metrics]);

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-navy-900 via-primary-950 to-slate-900 rounded-2xl p-6 sm:p-8 text-white border border-navy-800 shadow-xl">
        <div className="max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-200 text-xs font-semibold border border-teal-400/30">
            <TrendingUp className="w-3.5 h-3.5 text-teal-300" />
            <span>Campus Resource Utilization & Equity Analytics</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Laboratory Resource Analytics
          </h1>
          <p className="text-slate-300 text-sm leading-relaxed">
            Data-driven insights to eliminate laboratory resource hoarding. Track inter-departmental allocation,
            peak usage periods, idle hardware capacity, and student research demand.
          </p>
        </div>
      </div>

      {/* KPI Highlight Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Overall Campus Utilization</span>
            <Activity className="w-4 h-4 text-primary-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-slate-900">
            {overallUtilizationPct}%
          </div>
          <p className="text-[11px] text-slate-500">
            {currentlyIssuedUnits} active of {totalEquipmentUnits} total units
          </p>
        </div>

        {/* KPI 2 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Active Reservations</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-600">
            {bookingsList.filter((b) => ['approved', 'issued'].includes(b.status)).length}
          </div>
          <p className="text-[11px] text-slate-500">
            Approved or physically checked out
          </p>
        </div>

        {/* KPI 3 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Pending Review Queue</span>
            <Clock className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-amber-600">
            {pendingRequestsCount}
          </div>
          <p className="text-[11px] text-slate-500">
            Awaiting faculty prerequisite audit
          </p>
        </div>

        {/* KPI 4 */}
        <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs font-semibold">
            <span>Catalogued Instruments</span>
            <Layers className="w-4 h-4 text-violet-600" />
          </div>
          <div className="text-2xl sm:text-3xl font-extrabold text-violet-600">
            {equipmentList.length}
          </div>
          <p className="text-[11px] text-slate-500">
            Spanning 5 academic faculties
          </p>
        </div>
      </div>

      {/* Main Visualizations Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Department Utilization Bar Chart */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-primary-600" />
              <span>Department-Wise Laboratory Utilization</span>
            </h2>
            <span className="text-[11px] text-slate-400 font-medium">Real-Time Data</span>
          </div>

          <div className="space-y-3 pt-2">
            {deptBreakdown.map((dept) => (
              <div key={dept.department} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-slate-700 truncate max-w-[220px]">
                    {dept.department}
                  </span>
                  <span className="font-bold text-slate-900">
                    {dept.utilizationRate}% ({dept.activeBookings}/{dept.totalEquipment} in use)
                  </span>
                </div>
                <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                  <div
                    className={`${dept.barColor} h-full transition-all duration-500 rounded-full`}
                    style={{ width: `${Math.max(5, dept.utilizationRate)}%` }}
                  />
                </div>
              </div>
            ))}
          </div>

          <div className="p-3 bg-slate-50 rounded-xl text-[11px] text-slate-600 leading-relaxed border border-slate-100">
            💡 <strong>Resource Sharing Insight:</strong> Cross-departmental booking incentives have increased 
            sharing of Physics & Advanced Materials instruments with Computer Science students by 34%.
          </div>
        </div>

        {/* Most Demanded Equipment Ranking */}
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-600" />
              <span>Highest Contention Laboratory Equipment</span>
            </h2>
            <span className="text-[11px] text-slate-400 font-medium">By Booking Frequency</span>
          </div>

          <div className="space-y-2.5 pt-1">
            {equipmentRequestCounts.length > 0 ? (
              equipmentRequestCounts.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 rounded-xl bg-slate-50 border border-slate-100 text-xs"
                >
                  <div className="flex items-center gap-2.5">
                    <span className="w-5 h-5 rounded-md bg-slate-200 font-bold text-slate-700 flex items-center justify-center text-[10px]">
                      #{idx + 1}
                    </span>
                    <div>
                      <p className="font-bold text-slate-800">{item.name}</p>
                      <p className="text-[11px] text-slate-500">{item.dept}</p>
                    </div>
                  </div>
                  <span className="font-extrabold text-primary-700 bg-primary-50 px-2.5 py-1 rounded-lg border border-primary-200">
                    {item.count} Requests
                  </span>
                </div>
              ))
            ) : (
              <p className="text-xs text-slate-500 py-4 text-center">No booking request history yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
