import React, { useState, useMemo } from 'react';
import { 
  Search, 
  Filter, 
  MapPin, 
  Cpu, 
  CheckCircle2, 
  AlertCircle, 
  Layers, 
  PlusCircle, 
  SlidersHorizontal,
  X
} from 'lucide-react';
import { Equipment, Department, EquipmentCategory } from '../types';

interface EquipmentCatalogProps {
  equipmentList: Equipment[];
  onSelectForBooking: (equipment: Equipment) => void;
  onOpenRecommender: () => void;
}

export const EquipmentCatalog: React.FC<EquipmentCatalogProps> = ({
  equipmentList,
  onSelectForBooking,
  onOpenRecommender,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [onlyAvailable, setOnlyAvailable] = useState(false);
  const [selectedEquipmentDetail, setSelectedEquipmentDetail] = useState<Equipment | null>(null);

  // Departments list for filter buttons
  const departments: (Department | 'All')[] = [
    'All',
    'Computer Science & Engineering',
    'Electronics & Communication',
    'Electrical & Electronics',
    'Mechanical Engineering',
    'Physics & Advanced Materials',
  ];

  const categories: (EquipmentCategory | 'All')[] = [
    'All',
    'Development Kits & Embedded',
    'Test & Measurement',
    'Fabrication & Prototyping',
    'Computing & AI Workstations',
    'Optical & Spectroscopy',
    'Robotics & Automation',
  ];

  // Department color accent mapper
  const getDeptBadgeClass = (dept: Department) => {
    switch (dept) {
      case 'Computer Science & Engineering':
        return 'bg-blue-50 text-blue-700 border-blue-200';
      case 'Electronics & Communication':
        return 'bg-violet-50 text-violet-700 border-violet-200';
      case 'Electrical & Electronics':
        return 'bg-amber-50 text-amber-700 border-amber-200';
      case 'Mechanical Engineering':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      case 'Physics & Advanced Materials':
        return 'bg-teal-50 text-teal-700 border-teal-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  // Filter logic
  const filteredEquipment = useMemo(() => {
    return equipmentList.filter((item) => {
      const matchesSearch =
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.capabilities.some((c) => c.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesDept = selectedDept === 'All' || item.department === selectedDept;
      const matchesCategory = selectedCategory === 'All' || item.category === selectedCategory;
      const matchesAvailability = !onlyAvailable || item.availableQuantity > 0;

      return matchesSearch && matchesDept && matchesCategory && matchesAvailability;
    });
  }, [equipmentList, searchQuery, selectedDept, selectedCategory, onlyAvailable]);

  return (
    <div className="space-y-6">
      {/* Hero Banner */}
      <div className="relative rounded-2xl bg-gradient-to-r from-navy-900 via-primary-900 to-violet-950 p-6 sm:p-8 text-white overflow-hidden shadow-xl border border-navy-700">
        <div className="relative z-10 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary-500/20 text-primary-200 text-xs font-semibold mb-3 border border-primary-400/30">
            <Cpu className="w-3.5 h-3.5 text-primary-300" />
            <span>Cross-Department Laboratory Resource Sharing</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white mb-2 leading-tight">
            Discover Advanced University Equipment
          </h1>
          <p className="text-slate-300 text-sm sm:text-base leading-relaxed mb-5">
            Break departmental silos. Access high-performance computing clusters, specialized oscilloscopes, 
            rapid prototyping 3D printers, and optical spectroscopy instruments across all campus facilities.
          </p>
          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={onOpenRecommender}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-gradient-to-r from-primary-600 to-violet-600 hover:from-primary-500 hover:to-violet-500 text-white font-semibold text-sm shadow-lg shadow-primary-600/30 transition-all hover:scale-102"
            >
              <span>Match With My Project Description</span>
              <span className="px-1.5 py-0.5 rounded-md bg-white/20 text-xs">AI</span>
            </button>
            <div className="text-xs text-slate-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>13 Instruments catalogued across 5 faculties</span>
            </div>
          </div>
        </div>
      </div>

      {/* Search and Filters Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row gap-3">
          {/* Search Input */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Search by equipment name, capability, or keyword (e.g. 'A100', 'FPGA', '3D printer', 'spectroscopy')..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm outline-hidden transition-all"
              aria-label="Search laboratory equipment"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 p-1"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Category Dropdown */}
          <div className="relative min-w-[200px]">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm bg-white outline-hidden cursor-pointer"
              aria-label="Filter by category"
            >
              {categories.map((c) => (
                <option key={c} value={c}>
                  {c === 'All' ? 'All Categories' : c}
                </option>
              ))}
            </select>
          </div>

          {/* Only Available Toggle */}
          <button
            onClick={() => setOnlyAvailable(!onlyAvailable)}
            className={`inline-flex items-center gap-2 px-3.5 py-2.5 rounded-xl text-sm font-medium border transition-colors ${
              onlyAvailable
                ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
            }`}
            aria-pressed={onlyAvailable}
          >
            <CheckCircle2 className={`w-4 h-4 ${onlyAvailable ? 'text-emerald-600' : 'text-slate-400'}`} />
            <span>Available Now</span>
          </button>
        </div>

        {/* Department Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-slate-400 font-medium flex items-center gap-1 mr-1">
            <Filter className="w-3 h-3" />
            <span>Department:</span>
          </span>
          {departments.map((dept) => {
            const isSelected = selectedDept === dept;
            return (
              <button
                key={dept}
                onClick={() => setSelectedDept(dept)}
                className={`px-3 py-1.5 rounded-lg font-medium whitespace-nowrap transition-all ${
                  isSelected
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {dept}
              </button>
            );
          })}
        </div>
      </div>

      {/* Equipment Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {filteredEquipment.length > 0 ? (
          filteredEquipment.map((equipment) => {
            const isAvailable = equipment.availableQuantity > 0;
            return (
              <div
                key={equipment.id}
                className="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition-all flex flex-col justify-between overflow-hidden group"
              >
                <div className="p-5 space-y-3.5">
                  {/* Header badges */}
                  <div className="flex items-start justify-between gap-2">
                    <span className={`inline-block text-[11px] font-semibold px-2.5 py-0.5 rounded-full border ${getDeptBadgeClass(equipment.department)}`}>
                      {equipment.department.replace(' & ', ' / ')}
                    </span>
                    <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-full ${
                      isAvailable
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-rose-50 text-rose-700 border border-rose-200'
                    }`}>
                      <span className={`w-1.5 h-1.5 rounded-full ${isAvailable ? 'bg-emerald-500' : 'bg-rose-500'}`} />
                      {isAvailable ? `${equipment.availableQuantity} of ${equipment.totalQuantity} Available` : 'Reserved'}
                    </span>
                  </div>

                  {/* Title & Category */}
                  <div>
                    <h2 className="font-bold text-slate-900 text-base group-hover:text-primary-600 transition-colors line-clamp-2">
                      {equipment.name}
                    </h2>
                    <p className="text-xs text-slate-500 font-medium mt-0.5">{equipment.category}</p>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                    {equipment.description}
                  </p>

                  {/* Capabilities Tags */}
                  <div className="flex flex-wrap gap-1 pt-1">
                    {equipment.capabilities.slice(0, 3).map((cap) => (
                      <span
                        key={cap}
                        className="text-[10px] font-medium bg-slate-100 text-slate-600 px-2 py-0.5 rounded-md"
                      >
                        #{cap}
                      </span>
                    ))}
                    {equipment.capabilities.length > 3 && (
                      <span className="text-[10px] text-slate-400 font-medium px-1 py-0.5">
                        +{equipment.capabilities.length - 3} more
                      </span>
                    )}
                  </div>

                  {/* Lab Location */}
                  <div className="flex items-center gap-1.5 text-xs text-slate-500 pt-1 border-t border-slate-100">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{equipment.labLocation}</span>
                  </div>
                </div>

                {/* Card Footer Actions */}
                <div className="p-3 bg-slate-50/80 border-t border-slate-100 flex items-center justify-between gap-2">
                  <button
                    onClick={() => setSelectedEquipmentDetail(equipment)}
                    className="flex-1 py-2 px-3 text-xs font-semibold text-slate-700 hover:text-slate-900 hover:bg-slate-200/60 rounded-xl transition-colors text-center"
                    aria-label={`View details for ${equipment.name}`}
                  >
                    View Specs
                  </button>
                  <button
                    onClick={() => onSelectForBooking(equipment)}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-white bg-primary-600 hover:bg-primary-700 rounded-xl transition-colors shadow-xs"
                    aria-label={`Request booking for ${equipment.name}`}
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    <span>Request</span>
                  </button>
                </div>
              </div>
            );
          })
        ) : (
          <div className="col-span-full py-12 text-center bg-white rounded-2xl border border-slate-200">
            <SlidersHorizontal className="w-8 h-8 text-slate-400 mx-auto mb-2" />
            <h3 className="text-base font-semibold text-slate-800">No equipment found matching criteria</h3>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Try adjusting your search terms or relaxing category and availability filters.
            </p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedDept('All');
                setSelectedCategory('All');
                setOnlyAvailable(false);
              }}
              className="mt-3 px-3.5 py-1.5 text-xs font-semibold text-primary-600 bg-primary-50 rounded-lg hover:bg-primary-100"
            >
              Reset Filters
            </button>
          </div>
        )}
      </div>

      {/* Equipment Detailed Modal */}
      {selectedEquipmentDetail && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-title"
        >
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-4">
              <div>
                <span className={`inline-block text-[11px] font-semibold px-2.5 py-0.5 rounded-full border mb-1.5 ${getDeptBadgeClass(selectedEquipmentDetail.department)}`}>
                  {selectedEquipmentDetail.department}
                </span>
                <h3 id="modal-title" className="text-xl font-bold text-slate-900">
                  {selectedEquipmentDetail.name}
                </h3>
                <p className="text-xs text-slate-500">{selectedEquipmentDetail.category} • Tier: <span className="font-semibold text-slate-700">{selectedEquipmentDetail.hourlyRateTier}</span></p>
              </div>
              <button
                onClick={() => setSelectedEquipmentDetail(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors"
                aria-label="Close modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Description */}
            <div className="space-y-1">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500">Overview</h4>
              <p className="text-sm text-slate-700 leading-relaxed">
                {selectedEquipmentDetail.description}
              </p>
            </div>

            {/* Technical Specifications */}
            <div className="space-y-2">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-primary-600" />
                <span>Verified Hardware Specifications</span>
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 bg-slate-50 p-3 rounded-xl border border-slate-200 text-xs">
                {Object.entries(selectedEquipmentDetail.specifications).map(([key, value]) => (
                  <div key={key} className="space-y-0.5">
                    <span className="font-semibold text-slate-600">{key}:</span>
                    <span className="text-slate-800 ml-1">{value}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Prerequisites & Safety Requirements */}
            <div className="space-y-1.5">
              <h4 className="text-xs font-bold uppercase tracking-wider text-amber-600 flex items-center gap-1.5">
                <AlertCircle className="w-3.5 h-3.5" />
                <span>Prerequisites & Lab Compliance</span>
              </h4>
              <div className="bg-amber-50/60 border border-amber-200 p-3 rounded-xl text-xs space-y-1">
                {selectedEquipmentDetail.prerequisites.length > 0 ? (
                  selectedEquipmentDetail.prerequisites.map((prereq) => (
                    <div key={prereq} className="flex items-center gap-1.5 text-amber-900">
                      <CheckCircle2 className="w-3 h-3 text-amber-600 shrink-0" />
                      <span>{prereq}</span>
                    </div>
                  ))
                ) : (
                  <p className="text-slate-600">No special certifications required. Standard laboratory bench safety applies.</p>
                )}
                <p className="text-[11px] text-amber-700 italic pt-1">
                  Note: Prerequisites are formally inspected and confirmed by faculty during booking approval.
                </p>
              </div>
            </div>

            {/* Location & Availability */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs text-slate-600">
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4 text-primary-600" />
                <span>{selectedEquipmentDetail.labLocation}</span>
              </div>
              <div className="font-semibold">
                Available: {selectedEquipmentDetail.availableQuantity} of {selectedEquipmentDetail.totalQuantity} units
              </div>
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100">
              <button
                onClick={() => setSelectedEquipmentDetail(null)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
              >
                Close
              </button>
              <button
                onClick={() => {
                  const eq = selectedEquipmentDetail;
                  setSelectedEquipmentDetail(null);
                  onSelectForBooking(eq);
                }}
                className="px-5 py-2 text-xs font-semibold text-white bg-primary-600 hover:bg-primary-700 rounded-xl transition-colors shadow-md shadow-primary-500/20"
              >
                Proceed to Request Form
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
