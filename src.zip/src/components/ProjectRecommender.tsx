import React, { useState } from 'react';
import { 
  Sparkles, 
  Lightbulb, 
  CheckCircle2, 
  ArrowRight, 
  Building2, 
  Sliders, 
  Tag, 
  Plus
} from 'lucide-react';
import { Equipment, RecommendationResult } from '../types';
import { recommendEquipmentForProject } from '../algorithms/recommender';

interface ProjectRecommenderProps {
  equipmentList: Equipment[];
  onSelectEquipmentForBooking: (equipment: Equipment, projectTitle?: string, projectDesc?: string) => void;
}

export const ProjectRecommender: React.FC<ProjectRecommenderProps> = ({
  equipmentList,
  onSelectEquipmentForBooking,
}) => {
  const [projectTitle, setProjectTitle] = useState('');
  const [projectDescription, setProjectDescription] = useState('');
  const [result, setResult] = useState<RecommendationResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  // Pre-configured demonstration projects to test the recommender
  const sampleProjects = [
    {
      title: 'IoT-Based Smart Precision Irrigation System',
      description: 'I am building an IoT-based smart irrigation system using soil moisture sensors and a microcontroller for low-power edge inferencing.',
    },
    {
      title: 'Multimodal Radiology Diagnostic Model',
      description: 'Fine-tuning a 7B parameter deep learning large language model on chest X-ray scans with PyTorch and CUDA tensor cores.',
    },
    {
      title: 'FPGA Hardware Accelerator for Edge ResNet',
      description: 'Designing pipelined systolic array architecture in Verilog VHDL on a Zynq SoC FPGA development board for real-time computer vision.',
    },
    {
      title: 'Photovoltaic Perovskite Bandgap Characterization',
      description: 'Measuring thin-film semiconductor optical absorption and bandgap energy across ultraviolet and visible wavelengths with spectroscopy.',
    },
  ];

  const handleRunRecommender = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!projectDescription.trim()) return;

    setIsAnalyzing(true);
    // Provide a brief UI micro-delay to let the user observe the algorithmic capability analysis
    setTimeout(() => {
      const recommendation = recommendEquipmentForProject(projectDescription, projectTitle, equipmentList);
      setResult(recommendation);
      setIsAnalyzing(false);
    }, 200);
  };

  const handleApplySample = (sample: typeof sampleProjects[0]) => {
    setProjectTitle(sample.title);
    setProjectDescription(sample.description);
    const recommendation = recommendEquipmentForProject(sample.description, sample.title, equipmentList);
    setResult(recommendation);
  };

  return (
    <div className="space-y-6">
      {/* Header card */}
      <div className="bg-gradient-to-r from-violet-900 via-primary-900 to-navy-900 rounded-2xl p-6 sm:p-8 text-white border border-violet-800 shadow-xl">
        <div className="max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-400/20 text-violet-200 text-xs font-semibold border border-violet-400/30">
            <Sparkles className="w-3.5 h-3.5 text-violet-300" />
            <span>Deterministic Explainable Matching System</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Intelligent Project-Based Equipment Recommender
          </h1>
          <p className="text-slate-300 text-sm leading-relaxed">
            Describe what you are building in natural language. Our transparent matching engine evaluates 
            technical specifications, capability keywords, cross-department alternatives, and prerequisite requirements.
          </p>
        </div>
      </div>

      {/* Input Form & Sample Selector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-2xl p-6 border border-slate-200 shadow-xs space-y-4">
          <form onSubmit={handleRunRecommender} className="space-y-4">
            <div>
              <label htmlFor="project-title" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Project Title (Optional)
              </label>
              <input
                id="project-title"
                type="text"
                placeholder="e.g. IoT Precision Irrigation using Microcontrollers"
                value={projectTitle}
                onChange={(e) => setProjectTitle(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm outline-hidden"
              />
            </div>

            <div>
              <label htmlFor="project-desc" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5 flex items-center justify-between">
                <span>Project Description & Laboratory Goals *</span>
                <span className="text-[11px] font-normal text-slate-500">Natural language text</span>
              </label>
              <textarea
                id="project-desc"
                rows={4}
                required
                placeholder="e.g. I am building an IoT-based smart irrigation system using soil moisture sensors and a microcontroller to classify drought stress on-device..."
                value={projectDescription}
                onChange={(e) => setProjectDescription(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm outline-hidden resize-y"
              />
            </div>

            <div className="flex items-center justify-between pt-1">
              <span className="text-xs text-slate-500">
                {projectDescription.trim().split(/\s+/).filter(Boolean).length} words entered
              </span>
              <button
                type="submit"
                disabled={!projectDescription.trim() || isAnalyzing}
                className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-primary-600 hover:bg-primary-700 text-white font-semibold text-sm transition-all shadow-md shadow-primary-500/20 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isAnalyzing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                    <span>Analyzing Capabilities...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Analyze & Recommend Equipment</span>
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        {/* Quick Sample Prompts */}
        <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200 space-y-3">
          <div className="flex items-center gap-2 text-slate-800 font-bold text-sm">
            <Lightbulb className="w-4 h-4 text-amber-500" />
            <span>Try Demonstration Prompts</span>
          </div>
          <p className="text-xs text-slate-500 leading-relaxed">
            Select a verified student research scenario to inspect the deterministic matching logic:
          </p>
          <div className="space-y-2">
            {sampleProjects.map((sample, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handleApplySample(sample)}
                className="w-full text-left p-2.5 rounded-xl bg-white border border-slate-200 hover:border-primary-300 hover:bg-primary-50/40 text-xs transition-all space-y-1 group"
              >
                <div className="font-semibold text-slate-800 group-hover:text-primary-700">
                  {sample.title}
                </div>
                <div className="text-slate-500 line-clamp-2">
                  {sample.description}
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Recommender Output */}
      {result && (
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-6 animate-in fade-in slide-in-from-bottom-2 duration-200">
          {/* Analysis Header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
            <div>
              <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
                <span>Algorithmic Recommendation Analysis</span>
                <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
                  {result.primaryRecommendations.length} Primary Matches
                </span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Target Project: "{result.projectSummary}"
              </p>
            </div>

            {/* Detected keywords */}
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-xs font-semibold text-slate-500 mr-1 flex items-center gap-1">
                <Tag className="w-3 h-3" /> Matched Capabilities:
              </span>
              {result.detectedKeywords.map((kw) => (
                <span
                  key={kw}
                  className="text-xs font-medium bg-primary-50 text-primary-700 px-2.5 py-0.5 rounded-md border border-primary-200"
                >
                  {kw}
                </span>
              ))}
            </div>
          </div>

          {/* Primary Matches */}
          <div className="space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Recommended Equipment (Ranked by Compatibility)</span>
            </h4>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {result.primaryRecommendations.map((match) => (
                <div
                  key={match.equipment.id}
                  className="rounded-xl border border-primary-200 bg-gradient-to-b from-primary-50/30 to-white p-4 space-y-3 shadow-xs flex flex-col justify-between"
                >
                  <div className="space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <span className="text-[11px] font-semibold text-primary-700 bg-primary-100/80 px-2 py-0.5 rounded-md">
                        {match.matchScore}% Compatibility
                      </span>
                      <span className="text-[11px] text-slate-500 font-medium">
                        {match.equipment.availableQuantity} available
                      </span>
                    </div>

                    <h5 className="font-bold text-slate-900 text-sm">
                      {match.equipment.name}
                    </h5>

                    <div className="flex items-center gap-1 text-xs text-slate-500">
                      <Building2 className="w-3.5 h-3.5 text-slate-400" />
                      <span>{match.equipment.department}</span>
                    </div>

                    <div className="text-xs text-slate-600 bg-white p-2.5 rounded-lg border border-slate-200/80 leading-relaxed">
                      <strong className="text-slate-800">Match Reason: </strong>
                      {match.explanation}
                    </div>

                    {/* Prerequisites */}
                    {match.missingPrerequisites.length > 0 && (
                      <div className="text-[11px] text-amber-700 bg-amber-50 p-2 rounded-lg border border-amber-200">
                        <span className="font-semibold">Prerequisites: </span>
                        {match.missingPrerequisites.join(', ')}
                      </div>
                    )}
                  </div>

                  <button
                    onClick={() => onSelectEquipmentForBooking(match.equipment, projectTitle, projectDescription)}
                    className="w-full inline-flex items-center justify-center gap-1.5 py-2 px-3 text-xs font-semibold text-white bg-primary-600 hover:bg-primary-700 rounded-lg transition-colors shadow-xs"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Select for Booking Request</span>
                  </button>
                </div>
              ))}
            </div>
          </div>

          {/* Compatible Cross-Department Alternatives */}
          {result.compatibleAlternatives.length > 0 && (
            <div className="space-y-3 pt-3 border-t border-slate-100">
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-600 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-violet-600" />
                <span>Compatible Cross-Department Alternatives (Lower Queue Times)</span>
              </h4>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {result.compatibleAlternatives.map((alt) => (
                  <div
                    key={alt.equipment.id}
                    className="rounded-xl border border-violet-200 bg-violet-50/20 p-4 space-y-2 flex flex-col justify-between"
                  >
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-semibold text-violet-800">
                          {alt.equipment.name}
                        </span>
                        <span className="text-[11px] font-medium bg-violet-100 text-violet-800 px-2 py-0.5 rounded-md">
                          Alternative Option
                        </span>
                      </div>
                      <p className="text-xs text-slate-600">
                        {alt.explanation}
                      </p>
                      <p className="text-[11px] text-slate-500 italic">
                        {alt.alternativeReason}
                      </p>
                    </div>

                    <button
                      onClick={() => onSelectEquipmentForBooking(alt.equipment, projectTitle, projectDescription)}
                      className="mt-2 inline-flex items-center justify-center gap-1.5 py-1.5 px-3 text-xs font-semibold text-violet-700 bg-violet-100/70 hover:bg-violet-200/80 rounded-lg transition-colors"
                    >
                      <span>Choose Alternative</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
