import React, { useState, useMemo } from 'react';
import { 
  ShieldCheck, 
  Lock, 
  Key, 
  AlertTriangle, 
  PackageCheck, 
  PackageMinus 
} from 'lucide-react';
import { BookingRequest, Equipment, BookingStatus } from '../types';
import { updateBookingFacultyDecision, verifyFacultyCredential } from '../lib/db';
import { analyzeEquipmentConflicts } from '../algorithms/conflictEngine';

interface FacultyDashboardProps {
  bookings: BookingRequest[];
  equipmentList: Equipment[];
  departmentUsage: Record<string, number>;
  onRefresh: () => void;
}

export const FacultyDashboard: React.FC<FacultyDashboardProps> = ({
  bookings,
  equipmentList,
  departmentUsage,
  onRefresh,
}) => {
  // Security State: Passcode authentication
  const [facultyPasscode, setFacultyPasscode] = useState('');
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);

  // Active filter tab
  const [filterTab, setFilterTab] = useState<'pending' | 'active_issued' | 'all'>('pending');

  // Action state (for approve, reject, issue, return)
  const [actionBooking, setActionBooking] = useState<BookingRequest | null>(null);
  const [actionType, setActionType] = useState<'approve' | 'reject' | 'propose_alt' | 'issue' | 'return' | null>(null);
  const [actionNotes, setActionNotes] = useState('');
  const [altSlotDate, setAltSlotDate] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);

    if (verifyFacultyCredential(facultyPasscode)) {
      setIsAuthenticated(true);
    } else {
      setAuthError('Access Denied: Invalid faculty security credential. (Demo default: "LabLink2026!")');
    }
  };

  const handleExecuteAction = async () => {
    if (!actionBooking || !actionType) return;
    setIsProcessing(true);
    setActionError(null);

    let newStatus: BookingStatus = 'pending';
    let altSlotData = undefined;

    if (actionType === 'approve') newStatus = 'approved';
    if (actionType === 'reject') newStatus = 'rejected';
    if (actionType === 'issue') newStatus = 'issued';
    if (actionType === 'return') newStatus = 'returned';
    if (actionType === 'propose_alt') {
      newStatus = 'alternative_proposed';
      if (altSlotDate) {
        const start = new Date(altSlotDate).toISOString();
        const end = new Date(new Date(altSlotDate).getTime() + 4 * 60 * 60 * 1000).toISOString();
        altSlotData = {
          startDate: start,
          endDate: end,
          reason: actionNotes || 'Faculty adjusted time to mitigate lab contention.',
        };
      }
    }

    try {
      await updateBookingFacultyDecision(
        actionBooking.id,
        newStatus,
        facultyPasscode,
        actionNotes,
        altSlotData
      );

      // Close action modal and refresh list
      setActionBooking(null);
      setActionType(null);
      setActionNotes('');
      onRefresh();
    } catch (err: any) {
      setActionError(err.message || 'Operation failed. Backend security rejected request.');
    } finally {
      setIsProcessing(false);
    }
  };

  // Filtered booking groups
  const filteredBookings = useMemo(() => {
    if (filterTab === 'pending') {
      return bookings.filter((b) => b.status === 'pending');
    }
    if (filterTab === 'active_issued') {
      return bookings.filter((b) => ['approved', 'issued'].includes(b.status));
    }
    return bookings;
  }, [bookings, filterTab]);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-slate-900 via-primary-950 to-navy-900 rounded-2xl p-6 sm:p-8 text-white border border-slate-800 shadow-xl">
        <div className="max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-semibold border border-emerald-400/30">
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Secure Role-Protected Operations</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Faculty Laboratory Review & Issue Dashboard
          </h1>
          <p className="text-slate-300 text-sm leading-relaxed">
            Authorized portal for laboratory superintendents and faculty mentors. Verify student prerequisites,
            review readiness scores, resolve competing allocations, and manage physical instrument check-in/check-out.
          </p>
        </div>
      </div>

      {/* Security Gate: Login Modal / Screen if not authenticated */}
      {!isAuthenticated ? (
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6 sm:p-8 max-w-lg mx-auto text-center space-y-5 my-8">
          <div className="w-12 h-12 bg-primary-100 text-primary-700 rounded-2xl flex items-center justify-center mx-auto shadow-inner">
            <Lock className="w-6 h-6" />
          </div>

          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-900">
              Faculty Authentication Required
            </h2>
            <p className="text-xs text-slate-500 leading-relaxed">
              In accordance with security criteria, approval operations are backend-protected.
              Please provide your laboratory administrative key.
            </p>
          </div>

          {authError && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700">
              {authError}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-4 text-left">
            <div>
              <label htmlFor="faculty-key" className="block text-xs font-bold uppercase tracking-wider text-slate-600 mb-1 flex items-center gap-1.5">
                <Key className="w-3.5 h-3.5 text-slate-400" />
                <span>Administrative Passcode</span>
              </label>
              <input
                id="faculty-key"
                type="password"
                required
                placeholder="Enter passcode..."
                value={facultyPasscode}
                onChange={(e) => setFacultyPasscode(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm outline-hidden font-mono"
              />
              <span className="text-[11px] text-slate-400 mt-1 block">
                Evaluation Demo Credential: <strong className="text-primary-600 font-mono">LabLink2026!</strong>
              </span>
            </div>

            <button
              type="submit"
              className="w-full py-2.5 px-4 bg-primary-600 hover:bg-primary-700 text-white font-semibold text-sm rounded-xl transition-colors shadow-md shadow-primary-500/20"
            >
              Verify Credential & Unlock Portal
            </button>
          </form>
        </div>
      ) : (
        /* Authenticated Dashboard */
        <div className="space-y-5">
          {/* Top Control Bar */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Faculty Session Authenticated</span>
              </span>
              <button
                onClick={() => setIsAuthenticated(false)}
                className="text-xs text-slate-500 hover:text-slate-800 underline ml-2"
              >
                Lock Session
              </button>
            </div>

            {/* Filter Tabs */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setFilterTab('pending')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  filterTab === 'pending'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Pending Review ({bookings.filter((b) => b.status === 'pending').length})
              </button>
              <button
                onClick={() => setFilterTab('active_issued')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  filterTab === 'active_issued'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Issued / Active ({bookings.filter((b) => ['approved', 'issued'].includes(b.status)).length})
              </button>
              <button
                onClick={() => setFilterTab('all')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  filterTab === 'all'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All Records ({bookings.length})
              </button>
            </div>
          </div>

          {/* Bookings List */}
          <div className="space-y-4">
            {filteredBookings.length > 0 ? (
              filteredBookings.map((booking) => {
                const targetEquip = equipmentList.find((e) => e.id === booking.equipmentId);
                const hasPendingConflict = booking.status === 'pending' && targetEquip
                  ? analyzeEquipmentConflicts(targetEquip, bookings, departmentUsage).hasConflict
                  : false;

                const isIssued = booking.status === 'issued';
                const isOverdue = isIssued && new Date(booking.endDate).getTime() < Date.now();

                return (
                  <div
                    key={booking.id}
                    className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs hover:border-slate-300 transition-all space-y-4"
                  >
                    {/* Header Row */}
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-bold text-primary-700 bg-primary-50 px-2 py-0.5 rounded-md border border-primary-200">
                          {booking.bookingReference}
                        </span>
                        <h2 className="font-bold text-slate-900 text-sm sm:text-base">
                          {booking.equipmentName}
                        </h2>
                      </div>

                      <div className="flex items-center gap-2">
                        {hasPendingConflict && (
                          <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 border border-amber-300">
                            <AlertTriangle className="w-3 h-3 text-amber-600" />
                            <span>Schedule Contention</span>
                          </span>
                        )}

                        <span className={`text-[11px] font-extrabold uppercase px-2.5 py-0.5 rounded-full ${
                          booking.status === 'approved'
                            ? 'bg-emerald-100 text-emerald-800'
                            : booking.status === 'issued'
                            ? isOverdue ? 'bg-rose-100 text-rose-800 border border-rose-300 animate-pulse' : 'bg-blue-100 text-blue-800'
                            : booking.status === 'returned'
                            ? 'bg-slate-100 text-slate-700'
                            : booking.status === 'rejected'
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}>
                          {isOverdue ? '⚠️ Overdue' : booking.status}
                        </span>
                      </div>
                    </div>

                    {/* Applicant & Project Grid */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                      {/* Col 1: Student info */}
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold uppercase text-slate-400">Applicant:</span>
                        <p className="font-semibold text-slate-900">{booking.studentName}</p>
                        <p className="text-slate-500">{booking.studentEmail}</p>
                        <p className="text-slate-600 font-medium">{booking.department}</p>
                      </div>

                      {/* Col 2: Project Scope & Readiness */}
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold uppercase text-slate-400">Project Title:</span>
                        <p className="font-semibold text-slate-900 line-clamp-1">"{booking.projectTitle}"</p>
                        <div className="flex items-center gap-2 pt-0.5">
                          <span className="font-semibold text-slate-500">Readiness:</span>
                          <span className="font-bold text-primary-600">{booking.readinessScore}/100</span>
                          <span className="text-[10px] text-slate-400">Flex: {booking.schedulingFlexibility}</span>
                        </div>
                      </div>

                      {/* Col 3: Slots & Deadlines */}
                      <div className="space-y-1">
                        <span className="text-[10px] font-bold uppercase text-slate-400">Slot Requested:</span>
                        <p className="text-slate-800 font-medium">
                          {new Date(booking.startDate).toLocaleString([], { dateStyle: 'short', timeStyle: 'short' })}
                        </p>
                        <p className="text-slate-500 text-[11px]">
                          Deadline: <strong className="text-rose-600 font-semibold">{booking.projectDeadline}</strong>
                        </p>
                      </div>
                    </div>

                    {/* Prerequisites & Safety Check banner */}
                    {targetEquip && targetEquip.prerequisites.length > 0 && (
                      <div className="p-2.5 bg-amber-50/70 border border-amber-200 rounded-xl text-[11px] text-amber-900 flex items-center justify-between">
                        <div>
                          <strong className="font-semibold">Prerequisites to physically inspect: </strong>
                          <span>{targetEquip.prerequisites.join(' • ')}</span>
                        </div>
                        <span className="text-[10px] uppercase font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-md">
                          Faculty Sign-off Required
                        </span>
                      </div>
                    )}

                    {/* Action Buttons for Faculty */}
                    <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-end gap-2">
                      {booking.status === 'pending' && (
                        <>
                          <button
                            onClick={() => {
                              setActionBooking(booking);
                              setActionType('reject');
                            }}
                            className="px-3 py-1.5 text-xs font-semibold text-rose-700 bg-rose-50 hover:bg-rose-100 rounded-xl transition-colors border border-rose-200"
                          >
                            Reject Request
                          </button>
                          <button
                            onClick={() => {
                              setActionBooking(booking);
                              setActionType('propose_alt');
                            }}
                            className="px-3 py-1.5 text-xs font-semibold text-amber-800 bg-amber-50 hover:bg-amber-100 rounded-xl transition-colors border border-amber-200"
                          >
                            Propose Alternative
                          </button>
                          <button
                            onClick={() => {
                              setActionBooking(booking);
                              setActionType('approve');
                            }}
                            className="px-4 py-1.5 text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl transition-colors shadow-xs"
                          >
                            Approve Access
                          </button>
                        </>
                      )}

                      {booking.status === 'approved' && (
                        <button
                          onClick={() => {
                            setActionBooking(booking);
                            setActionType('issue');
                          }}
                          className="px-4 py-1.5 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl transition-colors shadow-xs flex items-center gap-1.5"
                        >
                          <PackageMinus className="w-3.5 h-3.5" />
                          <span>Check-Out / Issue to Student</span>
                        </button>
                      )}

                      {booking.status === 'issued' && (
                        <button
                          onClick={() => {
                            setActionBooking(booking);
                            setActionType('return');
                          }}
                          className="px-4 py-1.5 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-colors shadow-xs flex items-center gap-1.5"
                        >
                          <PackageCheck className="w-3.5 h-3.5" />
                          <span>Check-In / Confirm Return</span>
                        </button>
                      )}

                      {['returned', 'rejected'].includes(booking.status) && (
                        <span className="text-xs text-slate-400 font-medium italic">
                          Lifecycle finalized
                        </span>
                      )}
                    </div>
                  </div>
                );
              })
            ) : (
              <div className="bg-white rounded-2xl p-8 border border-slate-200 text-center text-slate-500 text-xs">
                No bookings found under the selected view.
              </div>
            )}
          </div>
        </div>
      )}

      {/* Action Confirmation Modal */}
      {actionBooking && actionType && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-4">
            <h3 className="text-lg font-bold text-slate-900 capitalize">
              Confirm Action: {actionType.replace('_', ' ')}
            </h3>

            <p className="text-xs text-slate-600">
              Applying administrative decision to booking <strong className="font-mono">{actionBooking.bookingReference}</strong> for <strong>{actionBooking.studentName}</strong> ({actionBooking.equipmentName}).
            </p>

            {actionError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700">
                {actionError}
              </div>
            )}

            {/* Alternative Slot Picker if propose_alt */}
            {actionType === 'propose_alt' && (
              <div>
                <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                  Proposed Alternative Start Time:
                </label>
                <input
                  type="datetime-local"
                  required
                  value={altSlotDate}
                  onChange={(e) => setAltSlotDate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-bold uppercase text-slate-600 mb-1">
                Faculty Notes / Reason (Will be visible to student):
              </label>
              <textarea
                rows={3}
                placeholder="Enter notes for this decision..."
                value={actionNotes}
                onChange={(e) => setActionNotes(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs"
              />
            </div>

            <div className="flex items-center justify-end gap-3 pt-2">
              <button
                type="button"
                onClick={() => {
                  setActionBooking(null);
                  setActionType(null);
                }}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="button"
                disabled={isProcessing}
                onClick={handleExecuteAction}
                className="px-5 py-2 text-xs font-semibold text-white bg-primary-600 hover:bg-primary-700 rounded-xl shadow-xs"
              >
                {isProcessing ? 'Updating...' : 'Confirm Decision'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
