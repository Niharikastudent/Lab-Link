import React, { useState, useEffect, useMemo } from 'react';
import { 
  X, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles, 
  Clock, 
  Calendar, 
  Copy, 
  Check, 
  ArrowRight,
  Info
} from 'lucide-react';
import { Equipment, Department } from '../types';
import { evaluateBookingReadiness, BookingFormData } from '../algorithms/readiness';
import { submitBooking } from '../lib/db';

interface BookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedEquipment: Equipment | null;
  initialProjectTitle?: string;
  initialProjectDescription?: string;
  onBookingCreated?: (bookingReference: string) => void;
}

export const BookingModal: React.FC<BookingModalProps> = ({
  isOpen,
  onClose,
  selectedEquipment,
  initialProjectTitle = '',
  initialProjectDescription = '',
  onBookingCreated,
}) => {
  // Today's default dates for convenient picker
  const tomorrowStr = useMemo(() => {
    const d = new Date(Date.now() + 86400000 * 1);
    d.setUTCHours(9, 0, 0, 0);
    return d.toISOString().slice(0, 16);
  }, []);

  const tomorrowEndStr = useMemo(() => {
    const d = new Date(Date.now() + 86400000 * 1);
    d.setUTCHours(13, 0, 0, 0);
    return d.toISOString().slice(0, 16);
  }, []);

  const nextWeekStr = useMemo(() => {
    const d = new Date(Date.now() + 86400000 * 7);
    return d.toISOString().slice(0, 10);
  }, []);

  const [formData, setFormData] = useState<BookingFormData>({
    studentName: '',
    studentEmail: '',
    department: 'Computer Science & Engineering',
    projectTitle: initialProjectTitle,
    projectDescription: initialProjectDescription,
    equipmentId: selectedEquipment?.id || '',
    startDate: tomorrowStr,
    endDate: tomorrowEndStr,
    projectDeadline: nextWeekStr,
    schedulingFlexibility: 'moderate',
    facultyGuide: '',
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdReference, setCreatedReference] = useState<string | null>(null);
  const [hasCopied, setHasCopied] = useState(false);
  const [submissionError, setSubmissionError] = useState<string | null>(null);

  // Sync props if equipment changes
  useEffect(() => {
    if (selectedEquipment) {
      setFormData((prev) => ({
        ...prev,
        equipmentId: selectedEquipment.id,
      }));
    }
  }, [selectedEquipment]);

  useEffect(() => {
    if (initialProjectTitle || initialProjectDescription) {
      setFormData((prev) => ({
        ...prev,
        projectTitle: initialProjectTitle || prev.projectTitle,
        projectDescription: initialProjectDescription || prev.projectDescription,
      }));
    }
  }, [initialProjectTitle, initialProjectDescription]);

  // Real-time Readiness Evaluation (Feature C)
  const readiness = useMemo(() => {
    return evaluateBookingReadiness(formData, selectedEquipment);
  }, [formData, selectedEquipment]);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmissionError(null);

    if (!selectedEquipment) {
      setSubmissionError('No laboratory equipment selected.');
      return;
    }

    if (!readiness.isReadyForSubmission) {
      setSubmissionError('Please complete the missing required fields before submitting.');
      return;
    }

    setIsSubmitting(true);
    try {
      const result = await submitBooking({
        studentName: formData.studentName,
        studentEmail: formData.studentEmail,
        department: formData.department as Department,
        projectTitle: formData.projectTitle,
        projectDescription: formData.projectDescription,
        equipmentId: selectedEquipment.id,
        equipmentName: selectedEquipment.name,
        requestedQuantity: 1,
        startDate: new Date(formData.startDate).toISOString(),
        endDate: new Date(formData.endDate).toISOString(),
        projectDeadline: formData.projectDeadline,
        schedulingFlexibility: formData.schedulingFlexibility,
        facultyGuide: formData.facultyGuide || undefined,
        readinessScore: readiness.score,
        readinessFeedback: readiness.suggestions,
      });

      setCreatedReference(result.bookingReference);
      if (onBookingCreated) {
        onBookingCreated(result.bookingReference);
      }
    } catch (err: any) {
      setSubmissionError(err.message || 'Failed to submit booking request.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleCopyCode = () => {
    if (createdReference) {
      navigator.clipboard.writeText(createdReference);
      setHasCopied(true);
      setTimeout(() => setHasCopied(false), 2000);
    }
  };

  const handleModalClose = () => {
    setCreatedReference(null);
    setSubmissionError(null);
    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="booking-modal-title"
    >
      <div className="bg-white rounded-2xl max-w-3xl w-full p-6 shadow-2xl border border-slate-200 my-8 space-y-6">
        {/* Success Confirmation Screen */}
        {createdReference ? (
          <div className="text-center py-6 space-y-4">
            <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8" />
            </div>

            <div className="space-y-1">
              <h2 className="text-2xl font-extrabold text-slate-900">
                Booking Request Successfully Submitted!
              </h2>
              <p className="text-sm text-slate-600 max-w-md mx-auto">
                Your request has been registered in the university reservation queue for faculty verification.
              </p>
            </div>

            {/* Secret Reference Box */}
            <div className="bg-slate-50 border-2 border-dashed border-primary-300 rounded-2xl p-5 max-w-md mx-auto space-y-2">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Your Private Booking Reference
              </span>
              <div className="flex items-center justify-center gap-3">
                <span className="text-2xl font-mono font-extrabold tracking-wider text-primary-700">
                  {createdReference}
                </span>
                <button
                  type="button"
                  onClick={handleCopyCode}
                  className="p-2 rounded-lg bg-primary-50 text-primary-600 hover:bg-primary-100 transition-colors"
                  aria-label="Copy reference token"
                >
                  {hasCopied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[11px] text-slate-500">
                ⚠️ Save this code! Use it in "Track Request" to view approvals, conflict resolutions, and issue status without needing a login account.
              </p>
            </div>

            <div className="pt-4 flex justify-center">
              <button
                type="button"
                onClick={handleModalClose}
                className="px-6 py-2.5 rounded-xl bg-slate-900 text-white font-semibold text-sm hover:bg-slate-800 transition-colors"
              >
                Done
              </button>
            </div>
          </div>
        ) : (
          /* Submission Form */
          <>
            <div className="flex items-start justify-between border-b border-slate-100 pb-4">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-primary-600">
                  Laboratory Access Application
                </span>
                <h2 id="booking-modal-title" className="text-xl font-extrabold text-slate-900">
                  Request Equipment: {selectedEquipment?.name || 'Lab Instrument'}
                </h2>
                <p className="text-xs text-slate-500">
                  Location: {selectedEquipment?.labLocation}
                </p>
              </div>
              <button
                type="button"
                onClick={handleModalClose}
                className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
                aria-label="Close booking modal"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Live Readiness Scoring Bar (Feature C) */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-slate-700 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-primary-600" />
                  <span>Real-Time Project Readiness Score:</span>
                </span>
                <span className={`font-extrabold text-sm ${
                  readiness.score >= 80 ? 'text-emerald-600' : readiness.score >= 55 ? 'text-amber-600' : 'text-rose-600'
                }`}>
                  {readiness.score} / 100 ({readiness.level})
                </span>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-200 h-2 rounded-full overflow-hidden">
                <div 
                  className={`h-full transition-all duration-300 ${
                    readiness.score >= 80 ? 'bg-emerald-500' : readiness.score >= 55 ? 'bg-amber-500' : 'bg-rose-500'
                  }`}
                  style={{ width: `${readiness.score}%` }}
                />
              </div>

              {/* Readiness Suggestions & Missing fields */}
              {readiness.missingFields.length > 0 && (
                <div className="text-[11px] text-rose-700 flex items-start gap-1 pt-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span>Missing required fields: {readiness.missingFields.join(', ')}</span>
                </div>
              )}

              {readiness.suggestions.length > 0 && (
                <div className="text-[11px] text-slate-600 space-y-0.5 pt-0.5">
                  {readiness.suggestions.slice(0, 2).map((sug, i) => (
                    <div key={i} className="flex items-start gap-1">
                      <span className="text-primary-500 font-bold">•</span>
                      <span>{sug}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Error banner */}
            {submissionError && (
              <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
                <span>{submissionError}</span>
              </div>
            )}

            {/* Form Fields */}
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="student-name" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Student Full Name *
                  </label>
                  <input
                    id="student-name"
                    type="text"
                    required
                    placeholder="e.g. Aarav Sharma"
                    value={formData.studentName}
                    onChange={(e) => setFormData({ ...formData, studentName: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm outline-hidden"
                  />
                </div>

                <div>
                  <label htmlFor="student-email" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    University Email *
                  </label>
                  <input
                    id="student-email"
                    type="email"
                    required
                    placeholder="e.g. aarav.sharma@uni.edu"
                    value={formData.studentEmail}
                    onChange={(e) => setFormData({ ...formData, studentEmail: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm outline-hidden"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label htmlFor="department" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Student Department / Branch *
                  </label>
                  <select
                    id="department"
                    value={formData.department}
                    onChange={(e) => setFormData({ ...formData, department: e.target.value as Department })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm bg-white outline-hidden cursor-pointer"
                  >
                    <option value="Computer Science & Engineering">Computer Science & Engineering</option>
                    <option value="Electronics & Communication">Electronics & Communication</option>
                    <option value="Electrical & Electronics">Electrical & Electronics</option>
                    <option value="Mechanical Engineering">Mechanical Engineering</option>
                    <option value="Physics & Advanced Materials">Physics & Advanced Materials</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="faculty-guide" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Faculty Guide / Supervisor (Optional)
                  </label>
                  <input
                    id="faculty-guide"
                    type="text"
                    placeholder="e.g. Dr. Ramesh Kumar"
                    value={formData.facultyGuide}
                    onChange={(e) => setFormData({ ...formData, facultyGuide: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="project-title-input" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Project Title *
                </label>
                <input
                  id="project-title-input"
                  type="text"
                  required
                  placeholder="e.g. Autonomous Greenhouse Edge AI Telemetry"
                  value={formData.projectTitle}
                  onChange={(e) => setFormData({ ...formData, projectTitle: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm outline-hidden"
                />
              </div>

              <div>
                <label htmlFor="project-desc-input" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center justify-between">
                  <span>Project Description & Laboratory Justification *</span>
                  <span className="text-[11px] font-normal text-slate-500">Min 15-30 words recommended</span>
                </label>
                <textarea
                  id="project-desc-input"
                  rows={3}
                  required
                  placeholder="Explain your experimental setup, specific parameters you need to measure on this equipment, and deliverables..."
                  value={formData.projectDescription}
                  onChange={(e) => setFormData({ ...formData, projectDescription: e.target.value })}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm outline-hidden resize-y"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="start-date" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                    <Calendar className="w-3 h-3 text-slate-400" />
                    <span>Slot Start *</span>
                  </label>
                  <input
                    id="start-date"
                    type="datetime-local"
                    required
                    value={formData.startDate}
                    onChange={(e) => setFormData({ ...formData, startDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-xs outline-hidden"
                  />
                </div>

                <div>
                  <label htmlFor="end-date" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-slate-400" />
                    <span>Slot End *</span>
                  </label>
                  <input
                    id="end-date"
                    type="datetime-local"
                    required
                    value={formData.endDate}
                    onChange={(e) => setFormData({ ...formData, endDate: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-xs outline-hidden"
                  />
                </div>

                <div>
                  <label htmlFor="project-deadline" className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Project Deadline *
                  </label>
                  <input
                    id="project-deadline"
                    type="date"
                    required
                    value={formData.projectDeadline}
                    onChange={(e) => setFormData({ ...formData, projectDeadline: e.target.value })}
                    className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-xs outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Scheduling Flexibility
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['strict', 'moderate', 'flexible'] as const).map((flex) => (
                    <label
                      key={flex}
                      className={`flex items-center justify-center gap-2 p-2 rounded-xl border text-xs font-medium cursor-pointer transition-all ${
                        formData.schedulingFlexibility === flex
                          ? 'border-primary-600 bg-primary-50 text-primary-700 font-bold'
                          : 'border-slate-200 bg-white text-slate-600 hover:bg-slate-50'
                      }`}
                    >
                      <input
                        type="radio"
                        name="schedulingFlexibility"
                        value={flex}
                        checked={formData.schedulingFlexibility === flex}
                        onChange={() => setFormData({ ...formData, schedulingFlexibility: flex })}
                        className="sr-only"
                      />
                      <span className="capitalize">{flex}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Lab Compliance Disclaimer */}
              <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-[11px] text-slate-500 flex items-start gap-2">
                <Info className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                <span>
                  <strong>Laboratory Compliance Notice:</strong> Submitting this request does not guarantee allocation. 
                  Fair-share scheduling conflict analysis will evaluate competing demands, and authorized faculty must 
                  physically verify prerequisites before issuing the instrument.
                </span>
              </div>

              {/* Form buttons */}
              <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={handleModalClose}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting || !readiness.isReadyForSubmission}
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-primary-600 hover:bg-primary-700 text-white font-semibold text-xs transition-all shadow-md shadow-primary-500/20 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? (
                    <>
                      <div className="w-3.5 h-3.5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      <span>Submitting Request...</span>
                    </>
                  ) : (
                    <>
                      <span>Submit Lab Access Request</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </form>
          </>
        )}
      </div>
    </div>
  );
};
