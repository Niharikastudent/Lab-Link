import React, { useState } from 'react';
import { 
  FlaskConical, 
  Search, 
  Sparkles, 
  Scale, 
  ShieldCheck, 
  BarChart3, 
  Ticket, 
  TerminalSquare, 
  Menu, 
  X,
  Database
} from 'lucide-react';
import { isSupabaseConfigured } from '../lib/supabase';

interface NavbarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenLookup: () => void;
  onOpenDemoConsole: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  onOpenLookup,
  onOpenDemoConsole,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'catalogue', label: 'Equipment Catalogue', icon: Search },
    { id: 'recommender', label: 'Project Recommender', icon: Sparkles },
    { id: 'conflicts', label: 'Fair-Share Engine', icon: Scale },
    { id: 'faculty', label: 'Faculty Portal', icon: ShieldCheck },
    { id: 'analytics', label: 'Lab Analytics', icon: BarChart3 },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Brand Logo */}
          <div 
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => setActiveTab('catalogue')}
            tabIndex={0}
            role="button"
            aria-label="LabLink Home"
            onKeyDown={(e) => e.key === 'Enter' && setActiveTab('catalogue')}
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary-600 to-violet-500 flex items-center justify-center text-white shadow-md shadow-primary-500/20 group-hover:scale-105 transition-transform">
              <FlaskConical className="w-5 h-5" aria-hidden="true" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-slate-900">Lab<span className="text-primary-600">Link</span></span>
                <span className="text-[10px] font-semibold uppercase tracking-wider px-1.5 py-0.5 rounded-full bg-violet-100 text-violet-700">UniShare</span>
              </div>
              <p className="text-[11px] text-slate-500 font-medium leading-tight">Inter-Department Resource Platform</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1" aria-label="Main Navigation">
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActiveTab(item.id)}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-primary-50 text-primary-700 font-semibold shadow-xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                  aria-current={isActive ? 'page' : undefined}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-primary-600' : 'text-slate-400'}`} aria-hidden="true" />
                  {item.label}
                </button>
              );
            })}
          </nav>

          {/* Action Tools */}
          <div className="hidden lg:flex items-center gap-2.5">
            {/* Database indicator pill */}
            <div 
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
                isSupabaseConfigured 
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-200' 
                  : 'bg-amber-50 text-amber-700 border-amber-200'
              }`}
              title={isSupabaseConfigured ? 'Connected to live Supabase PostgreSQL' : 'Operating in Local Storage Mock Store mode'}
            >
              <Database className="w-3 h-3" />
              <span>{isSupabaseConfigured ? 'Supabase' : 'Demo DB'}</span>
            </div>

            {/* Private Booking Lookup */}
            <button
              onClick={onOpenLookup}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors border border-slate-200 shadow-xs"
              aria-label="Track Booking by Reference Token"
            >
              <Ticket className="w-3.5 h-3.5 text-slate-500" />
              <span>Track Request</span>
            </button>

            {/* Evaluator Demo Console */}
            <button
              onClick={onOpenDemoConsole}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-violet-700 bg-violet-50 hover:bg-violet-100 border border-violet-200 rounded-lg transition-colors shadow-xs"
              aria-label="Open Evaluator Demo Console"
            >
              <TerminalSquare className="w-3.5 h-3.5 text-violet-600" />
              <span>Demo Console</span>
            </button>
          </div>

          {/* Mobile hamburger */}
          <div className="md:hidden flex items-center gap-2">
            <button
              onClick={onOpenDemoConsole}
              className="p-1.5 text-violet-600 bg-violet-50 rounded-lg border border-violet-200"
              aria-label="Demo Console"
            >
              <TerminalSquare className="w-4 h-4" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-slate-600 hover:text-slate-900 rounded-lg focus:outline-hidden"
              aria-label={mobileMenuOpen ? 'Close Menu' : 'Open Menu'}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-2 pb-4 space-y-1 shadow-lg">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveTab(item.id);
                  setMobileMenuOpen(false);
                }}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium ${
                  isActive ? 'bg-primary-50 text-primary-700 font-semibold' : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                <Icon className={`w-4 h-4 ${isActive ? 'text-primary-600' : 'text-slate-400'}`} />
                {item.label}
              </button>
            );
          })}
          <div className="pt-2 border-t border-slate-100 flex flex-col gap-2">
            <button
              onClick={() => {
                onOpenLookup();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 text-sm font-medium text-slate-700 bg-slate-100 rounded-lg"
            >
              <Ticket className="w-4 h-4" />
              <span>Track Booking with Reference Code</span>
            </button>
            <button
              onClick={() => {
                onOpenDemoConsole();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center justify-center gap-2 py-2 px-3 text-sm font-medium text-violet-700 bg-violet-50 rounded-lg border border-violet-200"
            >
              <TerminalSquare className="w-4 h-4" />
              <span>Open Evaluator Demo Console</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
