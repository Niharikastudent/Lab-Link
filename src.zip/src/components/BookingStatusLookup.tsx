import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Ticket, 
  Clock, 
  CheckCircle2, 
  AlertCircle, 
  XCircle, 
  Bell, 
  ShieldCheck,
  X
} from 'lucide-react';
import { BookingRequest, NotificationItem } from '../types';
import { fetchBookingByReference, fetchNotifications } from '../lib/db';

interface BookingStatusLookupProps {
  isOpen: boolean;
  onClose: () => void;
  initialReference?: string;
}

export const BookingStatusLookup: React.FC<BookingStatusLookupProps> = ({
  isOpen,
  onClose,
  initialReference = '',
}) => {
  const [referenceInput, setReferenceInput] = useState(initialReference);
  const [currentBooking, setCurrentBooking] = useState<BookingRequest | null>(null);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);

  // Auto-search if initialReference provided
  useEffect(() => {
    if (initialReference) {
      setReferenceInput(initialReference);
      handleSearch(initialReference);
    }
  }, [initialReference]);

  if (!isOpen) return null;

  const handleSearch = async (refToSearch?: string) => {
    const targetRef = (refToSearch || referenceInput).trim().toUpperCase();
    if (!targetRef) return;

    setIsLoading(true);
    setSearchError(null);
    setCurrentBooking(null);

    try {
      const booking = await fetchBookingByReference(targetRef);
      if (booking) {
        setCurrentBooking(booking);
        // Load tied notifications
        const tiedNotifs = await fetchNotifications(targetRef);
        setNotifications(tiedNotifs);
      } else {
        setSearchError(`No booking found matching reference "${targetRef}". Please check your code format (e.g. LL-7F2A-91K4).`);
      }
    } catch (err: any) {
      setSearchError('Error retrieving booking record. Please verify your connection.');
    } finally {
      setIsLoading(false);
    }
  };

  const getStatusBadge = (status: BookingRequest['status']) => {
    switch (status) {
      case 'approved':
        return {
          label: 'Approved by Faculty',
          bg: 'bg-emerald-50 text-emerald-800 border-emerald-300',
          icon: CheckCircle2,
        };
      case 'issued':
        return {
          label: 'Currently Issued (In-Use)',
          bg: 'bg-blue-50 text-blue-800 border-blue-300',
          icon: Clock,
        };
      case 'returned':
        return {
          label: 'Returned & Completed',
          bg: 'bg-slate-100 text-slate-800 border-slate-300',
          icon: CheckCircle2,
        };
      case 'rejected':
        return {
          label: 'Declined by Faculty',
          bg: 'bg-rose-50 text-rose-800 border-rose-300',
          icon: XCircle,
        };
      case 'alternative_proposed':
        return {
          label: 'Alternative Slot Proposed',
          bg: 'bg-amber-50 text-amber-800 border-amber-300',
          icon: AlertCircle,
        };
      case 'cancelled':
        return {
          label: 'Cancelled',
          bg: 'bg-slate-100 text-slate-600 border-slate-200',
          icon: XCircle,
        };
      default:
        return {
          label: 'Pending Faculty Review',
          bg: 'bg-amber-50 text-amber-800 border-amber-300',
          icon: Clock,
        };
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto"
      role="dialog"
      aria-modal="true"
      aria-labelledby="lookup-title"
    >
      <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 my-8 space-y-6">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-slate-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-primary-100 text-primary-700">
              <Ticket className="w-5 h-5" />
            </div>
            <div>
              <h2 id="lookup-title" className="text-xl font-bold text-slate-900">
                Track Laboratory Request
              </h2>
              <p className="text-xs text-slate-500">
                Enter your private booking reference code to view live approval status & notifications
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100"
            aria-label="Close track request modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Search input bar */}
        <div className="space-y-2">
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="e.g. LL-7F2A-91K4 or LL-9X1B-22M8"
                value={referenceInput}
                onChange={(e) => setReferenceInput(e.target.value.toUpperCase())}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-100 text-sm font-mono tracking-wider outline-hidden"
              />
            </div>
            <button
              type="button"
              onClick={() => handleSearch()}
              disabled={isLoading || !referenceInput.trim()}
              className="px-5 py-2.5 bg-primary-600 hover:bg-primary-700 text-white font-semibold text-xs rounded-xl shadow-xs transition-colors disabled:opacity-50"
            >
              {isLoading ? 'Searching...' : 'Lookup'}
            </button>
          </div>

          {/* Quick Demo Pill shortcuts */}
          <div className="flex items-center gap-1.5 text-[11px] text-slate-500">
            <span>Demo codes to inspect:</span>
            <button
              onClick={() => { setReferenceInput('LL-7F2A-91K4'); handleSearch('LL-7F2A-91K4'); }}
              className="font-mono text-primary-600 hover:underline"
            >
              LL-7F2A-91K4
            </button>
            <span>•</span>
            <button
              onClick={() => { setReferenceInput('LL-3C8D-44P9'); handleSearch('LL-3C8D-44P9'); }}
              className="font-mono text-primary-600 hover:underline"
            >
              LL-3C8D-44P9
            </button>
            <span>•</span>
            <button
              onClick={() => { setReferenceInput('LL-9X1B-22M8'); handleSearch('LL-9X1B-22M8'); }}
              className="font-mono text-primary-600 hover:underline"
            >
              LL-9X1B-22M8
            </button>
          </div>
        </div>

        {/* Error message */}
        {searchError && (
          <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-700 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-500 shrink-0" />
            <span>{searchError}</span>
          </div>
        )}

        {/* Booking Details Display */}
        {currentBooking && (
          <div className="space-y-5 animate-in fade-in duration-150">
            {/* Status Header */}
            {(() => {
              const status = getStatusBadge(currentBooking.status);
              const StatusIcon = status.icon;
              return (
                <div className={`p-4 rounded-xl border flex items-center justify-between ${status.bg}`}>
                  <div className="flex items-center gap-2.5">
                    <StatusIcon className="w-5 h-5 shrink-0" />
                    <div>
                      <div className="text-xs font-bold uppercase tracking-wider">
                        Current Status
                      </div>
                      <div className="font-extrabold text-sm sm:text-base">
                        {status.label}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="text-[11px] font-mono text-slate-600">Ref:</span>
                    <span className="font-mono font-bold text-xs ml-1 block">{currentBooking.bookingReference}</span>
                  </div>
                </div>
              );
            })()}

            {/* Lifecycle Timeline */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 block mb-3">
                Equipment Reservation Lifecycle
              </span>
              <div className="flex items-center justify-between text-xs font-semibold relative">
                <div className="absolute top-1/2 left-0 right-0 h-0.5 bg-slate-200 -z-0" />
                
                {/* Step 1 */}
                <div className="flex flex-col items-center gap-1 z-10 bg-slate-50 px-1">
                  <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs">
                    ✓
                  </div>
                  <span className="text-[10px] text-slate-700">Submitted</span>
                </div>

                {/* Step 2 */}
                <div className="flex flex-col items-center gap-1 z-10 bg-slate-50 px-1">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    ['approved', 'issued', 'returned'].includes(currentBooking.status)
                      ? 'bg-emerald-500 text-white'
                      : currentBooking.status === 'rejected'
                      ? 'bg-rose-500 text-white'
                      : 'bg-amber-400 text-amber-900'
                  }`}>
                    {['approved', 'issued', 'returned'].includes(currentBooking.status) ? '✓' : '2'}
                  </div>
                  <span className="text-[10px] text-slate-700">Approval</span>
                </div>

                {/* Step 3 */}
                <div className="flex flex-col items-center gap-1 z-10 bg-slate-50 px-1">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    ['issued', 'returned'].includes(currentBooking.status)
                      ? 'bg-emerald-500 text-white'
                      : 'bg-slate-200 text-slate-500'
                  }`}>
                    {['issued', 'returned'].includes(currentBooking.status) ? '✓' : '3'}
                  </div>
                  <span className="text-[10px] text-slate-700">Issued</span>
                </div>

                {/* Step 4 */}
                <div className="flex flex-col items-center gap-1 z-10 bg-slate-50 px-1">
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                    currentBooking.status === 'returned'
                      ? 'bg-emerald-500 text-white'
                      : 'bg-slate-200 text-slate-500'
                  }`}>
                    {currentBooking.status === 'returned' ? '✓' : '4'}
                  </div>
                  <span className="text-[10px] text-slate-700">Returned</span>
                </div>
              </div>
            </div>

            {/* Equipment & Timing Info */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs bg-white p-4 rounded-xl border border-slate-200">
              <div className="space-y-1">
                <span className="font-semibold text-slate-500">Equipment:</span>
                <p className="font-bold text-slate-900 text-sm">{currentBooking.equipmentName}</p>
                <p className="text-slate-600">{currentBooking.department}</p>
              </div>

              <div className="space-y-1">
                <span className="font-semibold text-slate-500">Applicant:</span>
                <p className="font-bold text-slate-900 text-sm">{currentBooking.studentName}</p>
                <p className="text-slate-600">{currentBooking.studentEmail}</p>
              </div>

              <div className="space-y-1 pt-2 border-t border-slate-100">
                <span className="font-semibold text-slate-500">Reserved Slot:</span>
                <p className="text-slate-800">
                  {new Date(currentBooking.startDate).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
                </p>
                <p className="text-slate-500 text-[11px]">to</p>
                <p className="text-slate-800">
                  {new Date(currentBooking.endDate).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })}
                </p>
              </div>

              <div className="space-y-1 pt-2 border-t border-slate-100">
                <span className="font-semibold text-slate-500">Project Deadline:</span>
                <p className="text-slate-800 font-semibold">{currentBooking.projectDeadline}</p>
                <span className="font-semibold text-slate-500 block mt-1">Readiness Score:</span>
                <p className="text-primary-700 font-bold">{currentBooking.readinessScore} / 100</p>
              </div>
            </div>

            {/* Project Details */}
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
              <span className="font-bold text-slate-700">Project Scope: "{currentBooking.projectTitle}"</span>
              <p className="text-slate-600 leading-relaxed">{currentBooking.projectDescription}</p>
            </div>

            {/* Faculty Notes */}
            {currentBooking.facultyNotes && (
              <div className="p-3 bg-primary-50/70 border border-primary-200 rounded-xl text-xs space-y-1">
                <span className="font-bold text-primary-900 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5 text-primary-600" />
                  <span>Faculty Review Notes</span>
                </span>
                <p className="text-primary-950">{currentBooking.facultyNotes}</p>
              </div>
            )}

            {/* Notifications tied to this booking (Feature G) */}
            {notifications.length > 0 && (
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                  <Bell className="w-3.5 h-3.5 text-primary-600" />
                  <span>In-App Status Notifications ({notifications.length})</span>
                </span>
                <div className="space-y-1.5">
                  {notifications.map((n) => (
                    <div
                      key={n.id}
                      className="p-2.5 rounded-lg border border-slate-200 bg-white text-xs space-y-0.5"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-slate-800">{n.title}</span>
                        <span className="text-[10px] text-slate-400">
                          {new Date(n.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <p className="text-slate-600">{n.message}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
