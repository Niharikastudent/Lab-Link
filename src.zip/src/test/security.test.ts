import { describe, it, expect, beforeEach } from 'vitest';
import { 
  verifyFacultyCredential, 
  updateBookingFacultyDecision, 
  fetchBookingByReference, 
  fetchNotifications 
} from '../lib/db';
import { mockDb } from '../lib/mockStore';

describe('Security & Privacy Enforcement', () => {
  beforeEach(() => {
    mockDb.resetDemoData();
  });

  it('rejects unauthorized faculty actions with security violation error', async () => {
    const bookings = mockDb.getBookings();
    const pendingBooking = bookings.find((b) => b.status === 'pending')!;

    // Attempting approval with invalid passcode
    await expect(
      updateBookingFacultyDecision(
        pendingBooking.id,
        'approved',
        'invalid_password_attempt',
        'Unauthorized approval attempt'
      )
    ).rejects.toThrow(/SECURITY VIOLATION/);

    // Verify status was NOT changed in database
    const bookingAfter = mockDb.getBookingByReference(pendingBooking.bookingReference);
    expect(bookingAfter?.status).toBe('pending');
  });

  it('permits administrative actions when verified with valid faculty credential', async () => {
    const bookings = mockDb.getBookings();
    const pendingBooking = bookings.find((b) => b.status === 'pending')!;

    // Authorized passcode
    const validPasscode = 'LabLink2026!';
    expect(verifyFacultyCredential(validPasscode)).toBe(true);

    const updated = await updateBookingFacultyDecision(
      pendingBooking.id,
      'approved',
      validPasscode,
      'Prerequisites verified in person.'
    );

    expect(updated.status).toBe('approved');
    expect(updated.facultyNotes).toBe('Prerequisites verified in person.');
  });

  it('ensures private booking lookup returns null for non-existent or invalid reference codes', async () => {
    const nonExistent = await fetchBookingByReference('LL-FAKE-9999');
    expect(nonExistent).toBeNull();

    const empty = await fetchBookingByReference('');
    expect(empty).toBeNull();
  });

  it('scopes notifications strictly to matching private booking reference tokens', async () => {
    const targetRef = 'LL-7F2A-91K4';
    const notifs = await fetchNotifications(targetRef);

    expect(notifs.length).toBeGreaterThan(0);
    // Every retrieved notification must belong to this specific student reference
    for (const n of notifs) {
      expect(n.bookingReference.toUpperCase()).toBe(targetRef.toUpperCase());
    }
  });
});
