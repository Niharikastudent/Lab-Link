import { describe, it, expect } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { EquipmentCatalog } from '../components/EquipmentCatalog';
import { INITIAL_EQUIPMENT } from '../data/seedEquipment';

describe('Accessibility & UI Component Integrity (Criterion 5)', () => {
  it('renders catalogue with accessible search, proper labels, and semantic elements', () => {
    const handleSelect = () => {};
    const handleOpenRecommender = () => {};

    render(
      <EquipmentCatalog
        equipmentList={INITIAL_EQUIPMENT}
        onSelectForBooking={handleSelect}
        onOpenRecommender={handleOpenRecommender}
      />
    );

    // Search input has proper accessible label
    const searchInput = screen.getByLabelText(/search laboratory equipment/i);
    expect(searchInput).toBeInTheDocument();

    // Category dropdown has accessible label
    const categorySelect = screen.getByLabelText(/filter by category/i);
    expect(categorySelect).toBeInTheDocument();

    // Filter by search works
    fireEvent.change(searchInput, { target: { value: 'oscilloscope' } });
    expect(screen.getByText(/Keysight DSOX3024T/i)).toBeInTheDocument();
  });

  it('renders equipment cards with visible department tags and non-color-only indicators', () => {
    render(
      <EquipmentCatalog
        equipmentList={INITIAL_EQUIPMENT}
        onSelectForBooking={() => {}}
        onOpenRecommender={() => {}}
      />
    );

    // Text-based availability badges ("Available" vs "Reserved") are used rather than relying only on color dots
    const availableTexts = screen.getAllByText(/Available/i);
    expect(availableTexts.length).toBeGreaterThan(0);
  });
});
