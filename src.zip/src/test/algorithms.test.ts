import { describe, it, expect } from 'vitest';
import { recommendEquipmentForProject } from '../algorithms/recommender';
import { evaluateBookingReadiness } from '../algorithms/readiness';
import { 
  doIntervalsOverlap, 
  calculateFairShareScore, 
  generateAlternativeSlots, 
  analyzeEquipmentConflicts 
} from '../algorithms/conflictEngine';
import { INITIAL_EQUIPMENT } from '../data/seedEquipment';
import { BookingRequest } from '../types';

describe('Project Recommender Algorithm (Feature B)', () => {
  it('correctly maps IoT & sensor project to Google Coral or embedded kits', () => {
    const prompt = 'I am building an IoT-based smart irrigation system using soil moisture sensors and a microcontroller for low-power edge inferencing.';
    const result = recommendEquipmentForProject(prompt, 'Smart Irrigation', INITIAL_EQUIPMENT);

    expect(result.detectedKeywords).toContain('iot');
    expect(result.detectedKeywords).toContain('sensor');
    expect(result.primaryRecommendations.length).toBeGreaterThan(0);
    
    // Top recommendation should be Edge TPU Coral board or embedded kit
    const topMatch = result.primaryRecommendations[0];
    expect(topMatch.equipment.name.toLowerCase()).toContain('coral');
    expect(topMatch.matchScore).toBeGreaterThanOrEqual(50);
    expect(topMatch.explanation).toContain('Directly supports your project');
  });

  it('correctly maps deep learning & large language model requests to NVIDIA DGX A100', () => {
    const prompt = 'Fine-tuning a multimodal transformer neural network with PyTorch and CUDA on hospital X-ray images.';
    const result = recommendEquipmentForProject(prompt, 'Medical Radiology LLM', INITIAL_EQUIPMENT);

    expect(result.detectedKeywords).toContain('transformer');
    expect(result.detectedKeywords).toContain('pytorch');
    expect(result.detectedKeywords).toContain('cuda');
    
    const a100Match = result.primaryRecommendations.find((m) => m.equipment.name.includes('A100'));
    expect(a100Match).toBeDefined();
    expect(a100Match!.matchScore).toBeGreaterThanOrEqual(70);
  });

  it('correctly provides compatible cross-department alternatives', () => {
    const prompt = 'Designing pipelined systolic array accelerator in Verilog on FPGA.';
    const result = recommendEquipmentForProject(prompt, 'FPGA Accelerator', INITIAL_EQUIPMENT);

    expect(result.primaryRecommendations[0].equipment.name).toContain('FPGA');
    expect(result.compatibleAlternatives.length).toBeGreaterThanOrEqual(0);
  });
});

describe('Project Readiness Engine (Feature C)', () => {
  const sampleEquipment = INITIAL_EQUIPMENT[0];

  it('awards high readiness score for complete, well-formed proposals', () => {
    const completeForm = {
      studentName: 'Aarav Sharma',
      studentEmail: 'aarav.sharma@uni.edu',
      department: 'Computer Science & Engineering',
      projectTitle: 'Autonomous Robotic Exploration and 3D Mapping in Dense Orchards',
      projectDescription: 'We are evaluating stereo depth disparity mapping and SLAM algorithms using an embedded camera unit. The experiment requires benchmarking point cloud latency across varying illumination levels to validate our IEEE journal submission.',
      equipmentId: sampleEquipment.id,
      startDate: '2026-11-26T09:00:00Z',
      endDate: '2026-11-26T13:00:00Z',
      projectDeadline: '2026-12-05',
      schedulingFlexibility: 'moderate' as const,
      facultyGuide: 'Dr. Ramesh Kumar',
    };

    const evaluation = evaluateBookingReadiness(completeForm, sampleEquipment);
    expect(evaluation.isReadyForSubmission).toBe(true);
    expect(evaluation.score).toBeGreaterThanOrEqual(80);
    expect(evaluation.level).toBe('High');
    expect(evaluation.missingFields).toHaveLength(0);
    expect(evaluation.facultySummary).toContain('Aarav Sharma');
  });

  it('identifies missing required fields and advises expansion when description is too brief', () => {
    const incompleteForm = {
      studentName: '',
      studentEmail: 'invalid-email',
      department: '',
      projectTitle: 'Test',
      projectDescription: 'Quick test',
      equipmentId: '',
      startDate: '',
      endDate: '',
      projectDeadline: '',
      schedulingFlexibility: 'strict' as const,
    };

    const evaluation = evaluateBookingReadiness(incompleteForm, null);
    expect(evaluation.isReadyForSubmission).toBe(false);
    expect(evaluation.score).toBeLessThan(50);
    expect(evaluation.level).toBe('Needs Improvement');
    expect(evaluation.missingFields).toContain('Student Name');
    expect(evaluation.missingFields).toContain('Valid University Email');
    expect(evaluation.missingFields).toContain('Equipment Selection');
  });

  it('detects inverted time slots where end is before start', () => {
    const invalidDatesForm = {
      studentName: 'Priya Nair',
      studentEmail: 'priya.n@uni.edu',
      department: 'Mechanical Engineering',
      projectTitle: 'Tensile Strength Testing of Carbon Fiber Composites',
      projectDescription: 'Conducting ASTM D3039 tensile testing on 12 carbon-fiber reinforced polymer specimens to determine tensile modulus and ultimate failure stress for capstone dissertation.',
      equipmentId: sampleEquipment.id,
      startDate: '2026-11-27T14:00:00Z',
      endDate: '2026-11-27T10:00:00Z', // Inverted!
      projectDeadline: '2026-12-10',
      schedulingFlexibility: 'flexible' as const,
    };

    const evaluation = evaluateBookingReadiness(invalidDatesForm, sampleEquipment);
    expect(evaluation.missingFields).toContain('Valid Time Slot (End date must be after Start date)');
  });
});

describe('Smart Fair-Share Conflict Engine (Feature D)', () => {
  it('correctly calculates interval overlaps', () => {
    // Overlapping: 9am-1pm vs 11am-3pm
    expect(doIntervalsOverlap(
      '2026-11-25T09:00:00Z',
      '2026-11-25T13:00:00Z',
      '2026-11-25T11:00:00Z',
      '2026-11-25T15:00:00Z'
    )).toBe(true);

    // Non-overlapping: 9am-12pm vs 1pm-4pm
    expect(doIntervalsOverlap(
      '2026-11-25T09:00:00Z',
      '2026-11-25T12:00:00Z',
      '2026-11-25T13:00:00Z',
      '2026-11-25T16:00:00Z'
    )).toBe(false);
  });

  it('prioritizes student with closer project deadline under fair-share scoring', () => {
    const equip = INITIAL_EQUIPMENT[0]; // DGX A100

    const urgentBooking: BookingRequest = {
      id: 'b-urgent',
      bookingReference: 'LL-URGENT',
      studentName: 'Rohan Deshmukh',
      studentEmail: 'rohan.d@uni.edu',
      department: 'Computer Science & Engineering',
      projectTitle: 'LLM Fine-Tuning',
      projectDescription: 'Final thesis presentation in 2 days. Comprehensive model evaluation on chest radiographs.',
      equipmentId: equip.id,
      equipmentName: equip.name,
      requestedQuantity: 1,
      startDate: '2026-11-25T09:00:00Z',
      endDate: '2026-11-25T17:00:00Z',
      projectDeadline: new Date(Date.now() + 86400000 * 2).toISOString().slice(0, 10), // 2 days
      schedulingFlexibility: 'strict',
      status: 'pending',
      readinessScore: 90,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const flexibleBooking: BookingRequest = {
      id: 'b-flexible',
      bookingReference: 'LL-FLEX',
      studentName: 'Pooja Hegde',
      studentEmail: 'pooja.h@uni.edu',
      department: 'Electronics & Communication',
      projectTitle: 'Antenna Optimization',
      projectDescription: 'Long-term exploratory research project with milestone in 25 days.',
      equipmentId: equip.id,
      equipmentName: equip.name,
      requestedQuantity: 1,
      startDate: '2026-11-25T10:00:00Z',
      endDate: '2026-11-25T16:00:00Z',
      projectDeadline: new Date(Date.now() + 86400000 * 25).toISOString().slice(0, 10), // 25 days
      schedulingFlexibility: 'flexible',
      status: 'pending',
      readinessScore: 85,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const scoreUrgent = calculateFairShareScore(urgentBooking, equip, {});
    const scoreFlexible = calculateFairShareScore(flexibleBooking, equip, {});

    // Urgent booking receives significantly higher deadline urgency score
    expect(scoreUrgent.deadlineUrgencyScore).toBeGreaterThan(scoreFlexible.deadlineUrgencyScore);
    expect(scoreUrgent.totalScore).toBeGreaterThan(scoreFlexible.totalScore);
  });

  it('generates viable non-overlapping alternative slots', () => {
    const booking: BookingRequest = {
      id: 'b-conflict',
      bookingReference: 'LL-TEST',
      studentName: 'Pooja Hegde',
      studentEmail: 'pooja.h@uni.edu',
      department: 'Electronics & Communication',
      projectTitle: 'Antenna Simulation',
      projectDescription: 'Testing RF antenna arrays with machine learning.',
      equipmentId: 'eq-cs-01',
      equipmentName: 'NVIDIA DGX A100',
      requestedQuantity: 1,
      startDate: '2026-11-25T09:00:00Z',
      endDate: '2026-11-25T13:00:00Z',
      projectDeadline: '2026-12-01',
      schedulingFlexibility: 'flexible',
      status: 'pending',
      readinessScore: 85,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const occupiedStart = new Date('2026-11-25T09:00:00Z').getTime();
    const occupiedEnd = new Date('2026-11-25T13:00:00Z').getTime();

    const alt = generateAlternativeSlots(booking, occupiedStart, occupiedEnd);
    expect(alt.suggestedStart).toBeDefined();
    expect(alt.suggestedEnd).toBeDefined();
    expect(new Date(alt.suggestedEnd).getTime()).toBeGreaterThan(new Date(alt.suggestedStart).getTime());
    expect(alt.reason.length).toBeGreaterThan(15);
  });

  it('detects no conflict when bookings do not overlap', () => {
    const equip = INITIAL_EQUIPMENT[0];
    const nonOverlappingBookings: BookingRequest[] = [
      {
        id: 'b-1',
        bookingReference: 'LL-1',
        studentName: 'Alice',
        studentEmail: 'alice@uni.edu',
        department: 'Computer Science & Engineering',
        projectTitle: 'Task 1',
        projectDescription: 'Morning experiment.',
        equipmentId: equip.id,
        equipmentName: equip.name,
        requestedQuantity: 1,
        startDate: '2026-11-25T08:00:00Z',
        endDate: '2026-11-25T11:00:00Z',
        projectDeadline: '2026-12-01',
        schedulingFlexibility: 'strict',
        status: 'approved',
        readinessScore: 80,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: 'b-2',
        bookingReference: 'LL-2',
        studentName: 'Bob',
        studentEmail: 'bob@uni.edu',
        department: 'Computer Science & Engineering',
        projectTitle: 'Task 2',
        projectDescription: 'Afternoon experiment.',
        equipmentId: equip.id,
        equipmentName: equip.name,
        requestedQuantity: 1,
        startDate: '2026-11-25T13:00:00Z', // 2 hours after Alice finishes!
        endDate: '2026-11-25T16:00:00Z',
        projectDeadline: '2026-12-05',
        schedulingFlexibility: 'flexible',
        status: 'pending',
        readinessScore: 85,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
    ];

    const result = analyzeEquipmentConflicts(equip, nonOverlappingBookings);
    expect(result.hasConflict).toBe(false);
    expect(result.competingBookings).toHaveLength(0);
  });
});
