import { describe, it, expect, beforeEach } from 'vitest';
import { MockDatabaseStore } from '../lib/mockStore';

describe('Equipment Lifecycle & Booking State Transitions (Feature F)', () => {
  let store: MockDatabaseStore;

  beforeEach(() => {
    store = new MockDatabaseStore();
    store.resetDemoData();
  });

  it('generates an unpredictable booking reference upon submission', () => {
    const booking = store.createBooking({
      studentName: 'Sanjay Dutt',
      studentEmail: 'sanjay@uni.edu',
      department: 'Electrical & Electronics',
      projectTitle: 'Battery Degradation Testing',
      projectDescription: 'Testing lithium pouch cells at varying C-rates.',
      equipmentId: 'eq-ee-01',
      equipmentName: 'Chroma 6310A Programmable DC Electronic Load',
      requestedQuantity: 1,
      startDate: '2026-11-28T09:00:00Z',
      endDate: '2026-11-28T13:00:00Z',
      projectDeadline: '2026-12-10',
      schedulingFlexibility: 'moderate',
      readinessScore: 88,
    });

    expect(booking.bookingReference).toMatch(/^LL-[2-9A-Z]{4}-[2-9A-Z]{4}$/);
    expect(booking.status).toBe('pending');

    // Tied notification should exist
    const notifs = store.getNotifications(booking.bookingReference);
    expect(notifs.length).toBeGreaterThan(0);
    expect(notifs[0].title).toContain('Submitted');
  });

  it('transitions from Pending -> Approved -> Issued -> Returned with proper quantity tracking', () => {
    // 1. Initial equipment state
    const equipBefore = store.getEquipmentById('eq-mech-01')!;
    const initialAvailable = equipBefore.availableQuantity;

    // 2. Submit new booking
    const booking = store.createBooking({
      studentName: 'Kavita Menon',
      studentEmail: 'kavita.m@uni.edu',
      department: 'Mechanical Engineering',
      projectTitle: 'Biocompatible Prosthetic Socket 3D Printing',
      projectDescription: 'Fabricating compliant lattice structure using Tough PLA on dual extrusion Ultimaker.',
      equipmentId: 'eq-mech-01',
      equipmentName: 'Ultimaker S5 Dual-Extrusion 3D Printer',
      requestedQuantity: 1,
      startDate: '2026-11-29T10:00:00Z',
      endDate: '2026-11-29T16:00:00Z',
      projectDeadline: '2026-12-12',
      schedulingFlexibility: 'strict',
      readinessScore: 92,
    });

    // 3. Faculty Approves
    const approved = store.updateBookingStatus(booking.id, 'approved', 'Approved by Lab Superintendent.');
    expect(approved.status).toBe('approved');
    expect(approved.facultyNotes).toBe('Approved by Lab Superintendent.');

    // 4. Student checks out / Faculty Issues equipment
    const issued = store.updateBookingStatus(booking.id, 'issued', 'Unit #1 checked out.');
    expect(issued.status).toBe('issued');
    expect(issued.issuedAt).toBeDefined();

    // Verify equipment capacity decreased by 1
    const equipIssued = store.getEquipmentById('eq-mech-01')!;
    expect(equipIssued.availableQuantity).toBe(initialAvailable - 1);

    // 5. Student Returns equipment
    const returned = store.updateBookingStatus(booking.id, 'returned', 'Returned clean and undamaged.');
    expect(returned.status).toBe('returned');
    expect(returned.returnedAt).toBeDefined();

    // Verify equipment capacity restored
    const equipReturned = store.getEquipmentById('eq-mech-01')!;
    expect(equipReturned.availableQuantity).toBe(initialAvailable);

    // Notifications check
    const notifs = store.getNotifications(booking.bookingReference);
    expect(notifs.some((n) => n.title.includes('Approved'))).toBe(true);
    expect(notifs.some((n) => n.title.includes('Issued'))).toBe(true);
    expect(notifs.some((n) => n.title.includes('Returned'))).toBe(true);
  });

  it('rejects booking with faculty justification', () => {
    const booking = store.createBooking({
      studentName: 'Dev Test',
      studentEmail: 'dev@uni.edu',
      department: 'Computer Science & Engineering',
      projectTitle: 'Test',
      projectDescription: 'Quick experiment',
      equipmentId: 'eq-cs-01',
      equipmentName: 'NVIDIA DGX A100',
      requestedQuantity: 1,
      startDate: '2026-11-30T10:00:00Z',
      endDate: '2026-11-30T12:00:00Z',
      projectDeadline: '2026-12-01',
      schedulingFlexibility: 'strict',
      readinessScore: 40,
    });

    const rejected = store.updateBookingStatus(booking.id, 'rejected', 'Prerequisite safety training missing.');
    expect(rejected.status).toBe('rejected');
    expect(rejected.facultyNotes).toContain('Prerequisite');

    const notifs = store.getNotifications(booking.bookingReference);
    expect(notifs.some((n) => n.type === 'alert')).toBe(true);
  });
});
